### UAT RHEL & Docker base setup for all VMs
A step-by-step guide for installing and configuring Docker on a new server and running applications and services within containers. 

### Prerequisites
1. Admin privileges and SSH access to the server
1. Server should have internet access to be able to download and install packages
1. x86_64 or ARM64 Linux VM with minimum 4 GB RAM and 10GB disk space

### RHEL installation (run under sudo)
1. `timedatectl set-timezone Asia/Kolkata` (set timezone to IST)
1. `yum update -y` (update system)
1. `dnf install -y vim nano wget curl git net-tools` (common utilities)
1. `yum install -y https://dl.fedoraproject.org/pub/epel/epel-release-latest-9.noarch.rpm` (extra packages for linux)
1. `dnf repolist` (verify EPEL repo is enabled)

### Docker installation (run under sudo)
1. `yum update -y`
1. Installation
    1. `rm -f /etc/yum.repos.d/docker-ce.repo` (clear repo)
    1. `yum-config-manager --add-repo=https://download.docker.com/linux/rhel/docker-ce.repo` (download docker)
	1. `vi /etc/yum.repos.d/docker-ce.repo` and global replace $releasever to 9
    1. `dnf install -y dnf-plugins-core` (update plugins)
    1. `dnf clean all` (clean up for installation)
    1. `dnf makecache` (prepare for installation)
    1. `dnf install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin --nobest` (install docker)
1. Configuration
	1. Add `10.91.16.33 nexus.northernarc.com` to /etc/hosts file (enables pulling artifacts from NACL's nexus server)
    1. `mkdir -p /nimbus/docker` (create custom directory for Docker)
    1. `vim /etc/docker/daemon.json` and add `{"data-root": "/data/docker", "insecure-registries":["nexus.northernarc.com"]}` (edit docker daemon configuration)
    1. `systemctl enable docker` (enable service)
    1. `systemctl start docker` (start service)
    1. `systemctl status docker` (check status)
	1. Login into nexus server using `docker login nexus.northernarc.com` with admin & Today123 (this is the nexus ID & password)