### README

### Order of execution. VMs correspond to DO's UAT instance
1. markdown_DO_setup_uat_rhel_docker.md (on all VMs. Postgres needs only RHEL. It runs as a service)
2. markdown_DO_setup_uat_main_nginx.md (on 10.91.20.59)
3. markdown_DO_setup_uat_postgres.md (on 10.91.20.57)
4. UM (on 10.91.20.63)
5. Application (on 10.91.20.61)
6. Airflow (on 10.91.20.58)
7. Dedupe (on 10.91.20.66)
8. Disbursement (on 10.91.20.60)
9. Kafka (on 10.91.20.64)
10. UI (on 10.91.20.61)
11. SRE (on 10.91.20.65)
12. Status (on 10.91.20.62)
