### UAT Eureka setup
A step-by-step guide for installing Eureka application.

### Prerequisites
1. Admin privileges and SSH access to the server
1. Server should have internet access to be able to download and install packages
1. x86_64 or ARM64 Linux VM with minimum 4 GB RAM and 10GB disk space

### TODO
1. Setup Java.
1. Setup Eureka Application


## Java Setup
1. `sudo yum install -y java-11-openjdk` 
1. `java --version` (Verify the installation)

## Eureka Setup

### Pre-reqs (run under sudo)
1. Copy the eureka.rar from [sharepoint](https://collaborate365.sharepoint.com/sites/NorthernArc/IT%20Program%20Management/DO%20optimization/Optimization%20setup%20document/Infra_setup_v2/DO%20Applications) and move it to local machine.
1. Extract the rar file and move the eureka folder to `/home/nacl_pam_admin/` in the current server.
1. `mkdir -p /nimbus/apps/api /nimbus/apps/logs`
1. `mv /home/nacl_pam_admin/eureka/ /nimbus/apps/api/`
1. `touch /etc/systemd/system/discovery-server.service`
1. Copy the following script into `/etc/systemd/system/discovery-server.service`
    ```
	[Unit]
	Description=nimbus
	After=syslog.target

	[Service]
	ExecStart=/bin/java -jar -Xmx1024m /nimbus/apps/api/eureka/discovery-server.jar

	[Install]
	WantedBy=multi-user.target
   ```
### Enable Eureka Service
1. `sudo systemctl enable discovery-server`   
   
### Boot up
1. `sudo systemctl start discovery-server` (start)
1. `sudo systemctl status discovery-server` (status)

### Test & Validate
1. Load the [Eureka](http://10.91.20.65:8761/eureka/) URL in browser to open Eureka UI. (Port 8761 should be exposed on firewall, and IP should be the current VM IP)
1. Check the Application logs using `sudo journalctl -fu discovery-server`
