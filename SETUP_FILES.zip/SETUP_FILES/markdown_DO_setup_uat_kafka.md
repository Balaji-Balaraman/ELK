
### Kafka Server Setup 

Server: 10.91.20.64
Server name: Paytm Kafka

### Prerequisites
1. Admin privileges to access and modify the server.
1. SSH access to the server using tools like PuTTY or MobaXterm.
1. Familiarity with Docker and Kafka basics.
1. Install docker and docker compose.

### Configuration Files

#### Download and Extract Kafka

1. `sudo su`
1. `mkdir -p /nimbus/kafka`
1. `cd /nimbus/kafka`
1. `wget https://downloads.apache.org/kafka/3.9.0/kafka_2.13-3.9.0.tgz`
1. `tar -xvzf kafka_2.13-3.9.0.tgz --strip 1`
1. `rm kafka_2.13-3.9.0.tgz`


> **Note:** If prompted with `rm: remove regular file 'kafka_2.13-3.9.0.tgz'?` press `Y` to confirm.

### Configuration Files Setup


1. `cd /nimbus/kafka/config/kraft/`
1. `ls`   # Check for server.properties file`
1. `mv /nimbus/kafka/config/kraft/server.properties /nimbus/kafka/config/kraft/server.properties_backup`
1. `touch /nimbus/kafka/config/kraft/server.properties /nimbus/kafka/config/kraft/server2.properties /nimbus/kafka/config/kraft/server3.properties`


#### Copy Configuration Files

1. `cp server.properties server2.properties`
1. `cp server.properties server3.properties`
1. `ls`   # Verify files created

#### Property modification

##### Modify server.properties:


1. `mv /nimbus/kafka/config/kraft/server.properties /nimbus/kafka/config/kraft/server_backup.properties`
1. `sudo vim /nimbus/kafka/config/kraft/server.properties`

<details>
		<summary>Click to expand</summary>
	
		# Licensed to the Apache Software Foundation (ASF) under one or more
		# contributor license agreements.  See the NOTICE file distributed with
		# this work for additional information regarding copyright ownership.
		# The ASF licenses this file to You under the Apache License, Version 2.0
		# (the "License"); you may not use this file except in compliance with
		# the License.  You may obtain a copy of the License at
		#
		#    http://www.apache.org/licenses/LICENSE-2.0
		#
		# Unless required by applicable law or agreed to in writing, software
		# distributed under the License is distributed on an "AS IS" BASIS,
		# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
		# See the License for the specific language governing permissions and
		# limitations under the License.

		#
		# This configuration file is intended for use in KRaft mode, where
		# Apache ZooKeeper is not present.
		#

		############################# Server Basics #############################

		# The role of this server. Setting this puts us in KRaft mode
		process.roles=controller,broker

		# The node id associated with this instance's roles
		node.id=1

		# The connect string for the controller quorum
		controller.quorum.voters=1@10.91.20.64:29093,2@10.91.20.64:29094,3@10.91.20.64:29095

		############################# Socket Server Settings #############################

		# The address the socket server listens on.
		# Combined nodes (i.e. those with `process.roles=broker,controller`) must list the controller listener here at a minimum.
		# If the broker listener is not defined, the default listener will use a host name that is equal to the value of java.net.InetAddress.getCanonicalHostName(),
		# with PLAINTEXT listener name, and port 9092.
		#   FORMAT:
		#     listeners = listener_name://host_name:port
		#   EXAMPLE:
		#     listeners = PLAINTEXT://your.host.name:9092
		listeners=PLAINTEXT://10.91.20.64:9092, CONTROLLER://10.91.20.64:29093

		# Name of listener used for communication between brokers.
		inter.broker.listener.name=PLAINTEXT

		# Listener name, hostname and port the broker or the controller will advertise to clients.
		# If not set, it uses the value for "listeners".
		advertised.listeners=PLAINTEXT://10.91.20.64:9092

		# A comma-separated list of the names of the listeners used by the controller.
		# If no explicit mapping set in `listener.security.protocol.map`, default will be using PLAINTEXT protocol
		# This is required if running in KRaft mode.
		controller.listener.names=CONTROLLER

		# Maps listener names to security protocols, the default is for them to be the same. See the config documentation for more details
		listener.security.protocol.map=CONTROLLER:PLAINTEXT,PLAINTEXT:PLAINTEXT,SSL:SSL,SASL_PLAINTEXT:SASL_PLAINTEXT,SASL_SSL:SASL_SSL

		# The number of threads that the server uses for receiving requests from the network and sending responses to the network
		num.network.threads=3

		# The number of threads that the server uses for processing requests, which may include disk I/O
		num.io.threads=8

		# The send buffer (SO_SNDBUF) used by the socket server
		socket.send.buffer.bytes=102400

		# The receive buffer (SO_RCVBUF) used by the socket server
		socket.receive.buffer.bytes=102400

		# The maximum size of a request that the socket server will accept (protection against OOM)
		socket.request.max.bytes=104857600


		############################# Log Basics #############################

		# A comma separated list of directories under which to store log files
		log.dirs=/nimbus/kafka/logs/kafka-1

		# The default number of log partitions per topic. More partitions allow greater
		# parallelism for consumption, but this will also result in more files across
		# the brokers.
		num.partitions=1

		# The number of threads per data directory to be used for log recovery at startup and flushing at shutdown.
		# This value is recommended to be increased for installations with data dirs located in RAID array.
		num.recovery.threads.per.data.dir=1

		############################# Internal Topic Settings  #############################
		# The replication factor for the group metadata internal topics "__consumer_offsets" and "__transaction_state"
		# For anything other than development testing, a value greater than 1 is recommended to ensure availability such as 3.
		offsets.topic.replication.factor=1
		transaction.state.log.replication.factor=1
		transaction.state.log.min.isr=1

		############################# Log Flush Policy #############################

		# Messages are immediately written to the filesystem but by default we only fsync() to sync
		# the OS cache lazily. The following configurations control the flush of data to disk.
		# There are a few important trade-offs here:
		#    1. Durability: Unflushed data may be lost if you are not using replication.
		#    2. Latency: Very large flush intervals may lead to latency spikes when the flush does occur as there will be a lot of data to flush.
		#    3. Throughput: The flush is generally the most expensive operation, and a small flush interval may lead to excessive seeks.
		# The settings below allow one to configure the flush policy to flush data after a period of time or
		# every N messages (or both). This can be done globally and overridden on a per-topic basis.

		# The number of messages to accept before forcing a flush of data to disk
		#log.flush.interval.messages=10000

		# The maximum amount of time a message can sit in a log before we force a flush
		#log.flush.interval.ms=1000

		############################# Log Retention Policy #############################

		# The following configurations control the disposal of log segments. The policy can
		# be set to delete segments after a period of time, or after a given size has accumulated.
		# A segment will be deleted whenever *either* of these criteria are met. Deletion always happens
		# from the end of the log.

		# The minimum age of a log file to be eligible for deletion due to age
		log.retention.hours=168

		# A size-based retention policy for logs. Segments are pruned from the log unless the remaining
		# segments drop below log.retention.bytes. Functions independently of log.retention.hours.
		#log.retention.bytes=1073741824

		# The maximum size of a log segment file. When this size is reached a new log segment will be created.
		log.segment.bytes=1073741824

		# The interval at which log segments are checked to see if they can be deleted according
		# to the retention policies
		log.retention.check.interval.ms=300000

		
</details>

> **Note:** add `insert` and modify only the given values then for save the changes press `esc` type `:wq`.

##### Modify server2.properties:


1. `mv /nimbus/kafka/config/kraft/server2.properties /nimbus/kafka/config/kraft/server2_backup.properties`
1. `sudo vim /nimbus/kafka/config/kraft/server2.properties`

<details>
		<summary>Click to expand</summary>
		
		# Licensed to the Apache Software Foundation (ASF) under one or more
		# contributor license agreements.  See the NOTICE file distributed with
		# this work for additional information regarding copyright ownership.
		# The ASF licenses this file to You under the Apache License, Version 2.0
		# (the "License"); you may not use this file except in compliance with
		# the License.  You may obtain a copy of the License at
		#
		#    http://www.apache.org/licenses/LICENSE-2.0
		#
		# Unless required by applicable law or agreed to in writing, software
		# distributed under the License is distributed on an "AS IS" BASIS,
		# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
		# See the License for the specific language governing permissions and
		# limitations under the License.

		#
		# This configuration file is intended for use in KRaft mode, where
		# Apache ZooKeeper is not present.
		#

		############################# Server Basics #############################

		# The role of this server. Setting this puts us in KRaft mode
		process.roles=controller,broker

		# The node id associated with this instance's roles
		node.id=2

		# The connect string for the controller quorum
		controller.quorum.voters=1@10.91.20.64:29093,2@10.91.20.64:29094,3@10.91.20.64:29095

		############################# Socket Server Settings #############################

		# The address the socket server listens on.
		# Combined nodes (i.e. those with `process.roles=broker,controller`) must list the controller listener here at a minimum.
		# If the broker listener is not defined, the default listener will use a host name that is equal to the value of java.net.InetAddress.getCanonicalHostName(),
		# with PLAINTEXT listener name, and port 9092.
		#   FORMAT:
		#     listeners = listener_name://host_name:port
		#   EXAMPLE:
		#     listeners = PLAINTEXT://your.host.name:9092
		listeners=PLAINTEXT://10.91.20.64:9094, CONTROLLER://10.91.20.64:29094

		# Name of listener used for communication between brokers.
		inter.broker.listener.name=PLAINTEXT

		# Listener name, hostname and port the broker or the controller will advertise to clients.
		# If not set, it uses the value for "listeners".
		advertised.listeners=PLAINTEXT://10.91.20.64:9094

		# A comma-separated list of the names of the listeners used by the controller.
		# If no explicit mapping set in `listener.security.protocol.map`, default will be using PLAINTEXT protocol
		# This is required if running in KRaft mode.
		controller.listener.names=CONTROLLER

		# Maps listener names to security protocols, the default is for them to be the same. See the config documentation for more details
		listener.security.protocol.map=CONTROLLER:PLAINTEXT,PLAINTEXT:PLAINTEXT,SSL:SSL,SASL_PLAINTEXT:SASL_PLAINTEXT,SASL_SSL:SASL_SSL

		# The number of threads that the server uses for receiving requests from the network and sending responses to the network
		num.network.threads=3

		# The number of threads that the server uses for processing requests, which may include disk I/O
		num.io.threads=8

		# The send buffer (SO_SNDBUF) used by the socket server
		socket.send.buffer.bytes=102400

		# The receive buffer (SO_RCVBUF) used by the socket server
		socket.receive.buffer.bytes=102400

		# The maximum size of a request that the socket server will accept (protection against OOM)
		socket.request.max.bytes=104857600


		############################# Log Basics #############################

		# A comma separated list of directories under which to store log files
		log.dirs=/nimbus/kafka/logs/kafka-2

		# The default number of log partitions per topic. More partitions allow greater
		# parallelism for consumption, but this will also result in more files across
		# the brokers.
		num.partitions=1

		# The number of threads per data directory to be used for log recovery at startup and flushing at shutdown.
		# This value is recommended to be increased for installations with data dirs located in RAID array.
		num.recovery.threads.per.data.dir=1

		############################# Internal Topic Settings  #############################
		# The replication factor for the group metadata internal topics "__consumer_offsets" and "__transaction_state"
		# For anything other than development testing, a value greater than 1 is recommended to ensure availability such as 3.
		offsets.topic.replication.factor=1
		transaction.state.log.replication.factor=1
		transaction.state.log.min.isr=1

		############################# Log Flush Policy #############################

		# Messages are immediately written to the filesystem but by default we only fsync() to sync
		# the OS cache lazily. The following configurations control the flush of data to disk.
		# There are a few important trade-offs here:
		#    1. Durability: Unflushed data may be lost if you are not using replication.
		#    2. Latency: Very large flush intervals may lead to latency spikes when the flush does occur as there will be a lot of data to flush.
		#    3. Throughput: The flush is generally the most expensive operation, and a small flush interval may lead to excessive seeks.
		# The settings below allow one to configure the flush policy to flush data after a period of time or
		# every N messages (or both). This can be done globally and overridden on a per-topic basis.

		# The number of messages to accept before forcing a flush of data to disk
		#log.flush.interval.messages=10000

		# The maximum amount of time a message can sit in a log before we force a flush
		#log.flush.interval.ms=1000

		############################# Log Retention Policy #############################

		# The following configurations control the disposal of log segments. The policy can
		# be set to delete segments after a period of time, or after a given size has accumulated.
		# A segment will be deleted whenever *either* of these criteria are met. Deletion always happens
		# from the end of the log.

		# The minimum age of a log file to be eligible for deletion due to age
		log.retention.hours=168

		# A size-based retention policy for logs. Segments are pruned from the log unless the remaining
		# segments drop below log.retention.bytes. Functions independently of log.retention.hours.
		#log.retention.bytes=1073741824

		# The maximum size of a log segment file. When this size is reached a new log segment will be created.
		log.segment.bytes=1073741824

		# The interval at which log segments are checked to see if they can be deleted according
		# to the retention policies
		log.retention.check.interval.ms=300000
		
</details>

> **Note:** add `insert` and modify only the given values then for save the changes press `esc` type `:wq`.

##### Modify server3.properties:

1. `mv /nimbus/kafka/config/kraft/server3.properties /nimbus/kafka/config/kraft/server3_backup.properties`
1. `sudo vim /nimbus/kafka/config/kraft/server3.properties`


<details>
		<summary>Click to expand</summary>
		
		# Licensed to the Apache Software Foundation (ASF) under one or more
		# contributor license agreements.  See the NOTICE file distributed with
		# this work for additional information regarding copyright ownership.
		# The ASF licenses this file to You under the Apache License, Version 2.0
		# (the "License"); you may not use this file except in compliance with
		# the License.  You may obtain a copy of the License at
		#
		#    http://www.apache.org/licenses/LICENSE-2.0
		#
		# Unless required by applicable law or agreed to in writing, software
		# distributed under the License is distributed on an "AS IS" BASIS,
		# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
		# See the License for the specific language governing permissions and
		# limitations under the License.

		#
		# This configuration file is intended for use in KRaft mode, where
		# Apache ZooKeeper is not present.
		#

		############################# Server Basics #############################

		# The role of this server. Setting this puts us in KRaft mode
		process.roles=controller,broker

		# The node id associated with this instance's roles
		node.id=3

		# The connect string for the controller quorum
		controller.quorum.voters=1@10.91.20.64:29093,2@10.91.20.64:29094,3@10.91.20.64:29095

		############################# Socket Server Settings #############################

		# The address the socket server listens on.
		# Combined nodes (i.e. those with `process.roles=broker,controller`) must list the controller listener here at a minimum.
		# If the broker listener is not defined, the default listener will use a host name that is equal to the value of java.net.InetAddress.getCanonicalHostName(),
		# with PLAINTEXT listener name, and port 9092.
		#   FORMAT:
		#     listeners = listener_name://host_name:port
		#   EXAMPLE:
		#     listeners = PLAINTEXT://your.host.name:9092
		listeners=PLAINTEXT://10.91.20.64:9095, CONTROLLER://10.91.20.64:29095

		# Name of listener used for communication between brokers.
		inter.broker.listener.name=PLAINTEXT

		# Listener name, hostname and port the broker or the controller will advertise to clients.
		# If not set, it uses the value for "listeners".
		advertised.listeners=PLAINTEXT://10.91.20.64:9095

		# A comma-separated list of the names of the listeners used by the controller.
		# If no explicit mapping set in `listener.security.protocol.map`, default will be using PLAINTEXT protocol
		# This is required if running in KRaft mode.
		controller.listener.names=CONTROLLER

		# Maps listener names to security protocols, the default is for them to be the same. See the config documentation for more details
		listener.security.protocol.map=CONTROLLER:PLAINTEXT,PLAINTEXT:PLAINTEXT,SSL:SSL,SASL_PLAINTEXT:SASL_PLAINTEXT,SASL_SSL:SASL_SSL

		# The number of threads that the server uses for receiving requests from the network and sending responses to the network
		num.network.threads=3

		# The number of threads that the server uses for processing requests, which may include disk I/O
		num.io.threads=8

		# The send buffer (SO_SNDBUF) used by the socket server
		socket.send.buffer.bytes=102400

		# The receive buffer (SO_RCVBUF) used by the socket server
		socket.receive.buffer.bytes=102400

		# The maximum size of a request that the socket server will accept (protection against OOM)
		socket.request.max.bytes=104857600


		############################# Log Basics #############################

		# A comma separated list of directories under which to store log files
		log.dirs=/nimbus/kafka/logs/kafka-3

		# The default number of log partitions per topic. More partitions allow greater
		# parallelism for consumption, but this will also result in more files across
		# the brokers.
		num.partitions=1

		# The number of threads per data directory to be used for log recovery at startup and flushing at shutdown.
		# This value is recommended to be increased for installations with data dirs located in RAID array.
		num.recovery.threads.per.data.dir=1

		############################# Internal Topic Settings  #############################
		# The replication factor for the group metadata internal topics "__consumer_offsets" and "__transaction_state"
		# For anything other than development testing, a value greater than 1 is recommended to ensure availability such as 3.
		offsets.topic.replication.factor=1
		transaction.state.log.replication.factor=1
		transaction.state.log.min.isr=1

		############################# Log Flush Policy #############################

		# Messages are immediately written to the filesystem but by default we only fsync() to sync
		# the OS cache lazily. The following configurations control the flush of data to disk.
		# There are a few important trade-offs here:
		#    1. Durability: Unflushed data may be lost if you are not using replication.
		#    2. Latency: Very large flush intervals may lead to latency spikes when the flush does occur as there will be a lot of data to flush.
		#    3. Throughput: The flush is generally the most expensive operation, and a small flush interval may lead to excessive seeks.
		# The settings below allow one to configure the flush policy to flush data after a period of time or
		# every N messages (or both). This can be done globally and overridden on a per-topic basis.

		# The number of messages to accept before forcing a flush of data to disk
		#log.flush.interval.messages=10000

		# The maximum amount of time a message can sit in a log before we force a flush
		#log.flush.interval.ms=1000

		############################# Log Retention Policy #############################

		# The following configurations control the disposal of log segments. The policy can
		# be set to delete segments after a period of time, or after a given size has accumulated.
		# A segment will be deleted whenever *either* of these criteria are met. Deletion always happens
		# from the end of the log.

		# The minimum age of a log file to be eligible for deletion due to age
		log.retention.hours=168

		# A size-based retention policy for logs. Segments are pruned from the log unless the remaining
		# segments drop below log.retention.bytes. Functions independently of log.retention.hours.
		#log.retention.bytes=1073741824

		# The maximum size of a log segment file. When this size is reached a new log segment will be created.
		log.segment.bytes=1073741824

		# The interval at which log segments are checked to see if they can be deleted according
		# to the retention policies
		log.retention.check.interval.ms=300000
		
</details>


> **Note:** add `insert` and modify only the given values then for save the changes press `esc` type `:wq`.

#### Create Log Folders:

1. `sudo mkdir -p /nimbus/kafka/logs/kafka-1`
1. `sudo mkdir -p /nimbus/kafka/logs/kafka-2`
1. `sudo mkdir -p /nimbus/kafka/logs/kafka-3`


#### check java version:

1. `java -version` - suppose output is 'java : command not found' then proceed with java install command.
1. `sudo yum install -y java-17-openjdk`

#### Generate Cluster ID (Only Once):

1. `CLUSTER_ID=$(/nimbus/kafka/bin/kafka-storage.sh random-uuid)`
1. `echo "Cluster ID: $CLUSTER_ID"`


#### Format Storage for Each Server:

1. `/nimbus/kafka/bin/kafka-storage.sh format -t $CLUSTER_ID -c /nimbus/kafka/config/kraft/server.properties`
1. `/nimbus/kafka/bin/kafka-storage.sh format -t $CLUSTER_ID -c /nimbus/kafka/config/kraft/server2.properties`
1. `/nimbus/kafka/bin/kafka-storage.sh format -t $CLUSTER_ID -c /nimbus/kafka/config/kraft/server3.properties`


---

#### Create the Kafka Systemd Service Files

<details>
		<summary>Click to expand</summary>
		
		cat <<EOF | sudo tee /etc/systemd/system/kafka-1.service
	[Unit]
	Description=Apache Kafka Broker 1 (KRaft Mode)
	After=network.target

	[Service]
	User=root
	Group=root
	Restart=on-failure
	RestartSec=5
	LimitNOFILE=100000

	Environment="KAFKA_HEAP_OPTS=-Xmx1G -Xms1G"
	ExecStart=/nimbus/kafka/bin/kafka-server-start.sh /nimbus/kafka/config/kraft/server.properties
	ExecStop=/nimbus/kafka/bin/kafka-server-stop.sh

	[Install]
	WantedBy=multi-user.target
	EOF

		
</details>

**Kafka Broker 2 Service:**
<details>
		<summary>Click to expand</summary>
		
		cat <<EOF | sudo tee /etc/systemd/system/kafka-2.service
	[Unit]
	Description=Apache Kafka Broker 2 (KRaft Mode)
	After=network.target

	[Service]
	User=root
	Group=root
	Restart=on-failure
	RestartSec=5
	LimitNOFILE=100000

	Environment="KAFKA_HEAP_OPTS=-Xmx1G -Xms1G"
	ExecStart=/nimbus/kafka/bin/kafka-server-start.sh /nimbus/kafka/config/kraft/server2.properties
	ExecStop=/nimbus/kafka/bin/kafka-server-stop.sh

	[Install]
	WantedBy=multi-user.target
	EOF

		
</details>

**Kafka Broker 3 Service:**
<details>
		<summary>Click to expand</summary>
		
		cat <<EOF | sudo tee /etc/systemd/system/kafka-3.service
	[Unit]
	Description=Apache Kafka Broker 3 (KRaft Mode)
	After=network.target

	[Service]
	User=root
	Group=root
	Restart=on-failure
	RestartSec=5
	LimitNOFILE=100000

	Environment="KAFKA_HEAP_OPTS=-Xmx1G -Xms1G"
	ExecStart=/nimbus/kafka/bin/kafka-server-start.sh /nimbus/kafka/config/kraft/server3.properties
	ExecStop=/nimbus/kafka/bin/kafka-server-stop.sh

	[Install]
	WantedBy=multi-user.target
	EOF

		
</details>

#### Enable and Start Services:

1. `sudo systemctl daemon-reload`
1. `sudo systemctl enable kafka-1 kafka-2 kafka-3`
1. `sudo systemctl start kafka-1 kafka-2 kafka-3`
1. `sudo systemctl status kafka-1 kafka-2 kafka-3`


#### To verify files are created:

1. `cd /etc/systemd/system/`
1. `ls`

>**Note** If SELinux is enforcing security policies, it may be blocking execution use -`sudo setenforce 0`. To revert `sudo setenforce 1`.


#### Verify Kafka Cluster:

1. `/nimbus/kafka/bin/kafka-metadata-quorum.sh --bootstrap-server "10.91.20.64:9092" describe --status`

#### 1.11 Check All Brokers:

1. `/nimbus/kafka/bin/kafka-broker-api-versions.sh --bootstrap-server "10.91.20.64:9092"`

#### Stop and Restart the kafka server
1. `sudo systemctl stop kafka-1 kafka-2 kafka-3` - stop Kafka Service
1. `sudo systemctl status kafka-1 kafka-2 kafka-3` -  status of the service
1. `sudo systemctl restart kafka-1 kafka-2 kafka-3` - restart Kafka Service
1. `sudo systemctl status kafka-1 kafka-2 kafka-3` -  status of the service

#### Create docker-compose.yml

##### Create the file in `/nimbus/kafka`:

1. `cd /nimbus/kafka`
1. `touch docker-compose.yaml`
1. `sudo nano docker-compose.yaml`

>yaml file will open now past this file content there. Then press `ctrl+O`, `enter` , `ctrl+X`.

<details>
		<summary>Compose file content</summary>
		
	services:
	  redis:
	    image: redis:latest
	    container_name: redis
 	    ports:
	      - 8083:6379

	  kafbat-ui:
	    container_name: kafbat-ui
	    image: ghcr.io/kafbat/kafka-ui:latest
	    ports:
	      - 8081:8080
	    environment:
	      KAFKA_CLUSTERS_0_NAME: kafka1
	      KAFKA_CLUSTERS_0_BOOTSTRAPSERVERS: 10.91.20.64:9092, 10.91.20.64:9094, 10.91.20.64:9095
	      AUTH_TYPE: "LOGIN_FORM"
	      SPRING_SECURITY_USER_NAME: admin
	      SPRING_SECURITY_USER_PASSWORD: admin


</details>


#### Start Services with Docker Compose

1. `sudo docker compose up -d`


#### Opening kafka port in the firewall 
1. `sudo firewall-cmd --add-port=9092/tcp --permanent`
1. `sudo firewall-cmd --add-port=9095/tcp --permanent`
1. `sudo firewall-cmd --add-port=9094/tcp --permanent`
1. `sudo firewall-cmd --reload`


#### Verification
1. `sudo docker compose ps` check kafka running
1. `http://10.91.20.64:8081/login` check UI in web-browser use credentials which have set on on docker-compose.yaml file

#### Logs and Troubleshooting

##### Logs
1. `cd /nimbus/kafka/logs` - navigates to kafka logs/kafka-1
1. `docker compose logs -f` - check container logs

##### Common issues
1. Kafka broker not starting - check docker-compose.yaml for error
1. Authentication error - verify credentials in docker-compose.yaml
1. UI not accessible - check if kafka UI is running or verify port mapping in docker-compose.yaml
1. Resource limitation - ensure server has sufficient RAM and disk space
1. monitor resource usage using htop or docker status