### UAT Postgres setup
A step-by-step guide for installing postgres and copying over data. 

### Prerequisites
1. Admin privileges and SSH access to the server
1. Server should have internet access to be able to download and install packages
1. x86_64 or ARM64 Linux VM with minimum 4 GB RAM and 10GB disk space

### Pre-reqs (run under sudo)
1. Setup RHEL (from markdown_DO_setup_uat_rhel_docker.md file) on this VM. Docker set up is not needed.
1. `rm -rf /etc/dnf/vars/releasever` 
1. `dnf --disablerepo='*' remove 'rhui-azure-rhel9-eus'` (remove EUS repo)
1. `dnf --config='https://rhelimage.blob.core.windows.net/repositories/rhui-microsoft-azure-rhel9.config' install rhui-azure-rhel9` (add non EUS repo)
1. `yum clean all`
1. `dnf install https://download.postgresql.org/pub/repos/yum/reporpms/EL-9-x86_64/pgdg-redhat-repo-latest.noarch.rpm -y`(download & install PostgreSQL)
1. `dnf -qy module disable postgresql` (avoid conflicts with default PostgreSQL modules)
1. `dnf install -y postgresql16-server` (install DB)

### Configure DB
1. `mkdir -p /data/npos_db/pgsql/16/data/`
1. `chown postgres:postgres /data/npos_db/pgsql/16/data/`
1. `chmod 700 /data/npos_db/pgsql/16/data/`
1. `su - postgres -c "/usr/pgsql-16/bin/initdb -D /data/npos_db/pgsql/16/data/"` (run init script as postgres user)
1. `systemctl enable postgresql-16` (enable postgres service)
1. In file "/etc/systemd/system/multi-user.target.wants/postgresql-16.service" replace "/var/lib/pgsql/16/data/" against "Environment=PGDATA=" (~ line 29) variable to "/data/npos_db/pgsql/16/data/"
1. `systemctl daemon-reload` (reload changes)
1. Update `/data/npos_db/pgsql/16/data/postgresql.conf` 
   1. port 5643 (default is 5432)
   1. listen_addresses = '*'
   1. max_connections = 500
   1. timezone = 'Asia/Kolkata';
   1. log_timezone = 'Asia/Kolkata';
1. Update `/data/npos_db/pgsql/16/data/pg_hba.conf` file
   1. Add the following two lines towards the end of the file (where other connection config is placed)
       1. `host    all             all             10.91.20.57/32          md5`
	   1. `host    all             all             10.60.35.0/24           scram-sha-256`
1. `systemctl status postgresql-16` (check status and start)
1. `systemctl start postgresql-16` (check status and start)
1. `dnf install postgresql16-contrib -y` (install crypto package)
1. `ls /usr/pgsql-16/share/extension/pgcrypto.control` (verify it is installed)
1. `systemctl restart postgresql-16` (restart postgres)
1. `sudo -u postgres psql -p 5643` (login to postgres)
1. `CREATE EXTENSION pgcrypto;` (create crypto extension)
1. `SELECT gen_random_uuid();` (verify installation)
1. `SELECT * FROM pg_extension WHERE extname = 'pgcrypto';` (verify crypto's installation)
1. `\q` (exit postgres)

### Validate DB (from linux terminal not from within postgres)
1. `su - postgres -c "psql -p 5643 -c 'SHOW data_directory;'"` (should return 1 record)

## Attach password to postgres user
1. `sudo -u postgres psql -p 5643` (login to postgres)
1. `ALTER USER postgres WITH PASSWORD 'N!mbu$Dev2oz1'`;
1. Validate this user/password by logging in

## Create DB in 10.91.20.40
1. `sudo -u postgres psql -p 5643` (login to postgres)
1. `CREATE database nimbus_credit_processor;` (create the db)
1. `\q`(exit postgres)

## Create the following users and roles
1. `nohup pg_dumpall -h 10.91.20.40 -p 5643 -U postgres --globals-only > global_roles_dump.sql &` (take user dump)
1. `psql -h localhost -p 5643 -U postgres -f global_roles_dump.sql` (restore users - remove ones corresponding to postgres. It is already present)
1. `nohup pg_dump -h 10.91.20.40 -p 5643 -U postgres nimbus_credit_processor > /data/nimbus_credit_processor &` (take the data dump)
1. `nohup psql -h 127.0.0.1 -p 5643 -U postgres nimbus_credit_processor <  /data/nimbus_credit_processor &` (restore the data dump)

## Cleanup
1. `rm -rf /data/nimbus_credit_processor`
1. `rm -rf global_roles_dump.sql`

### Folders
1. `/data/npos_db/pgsql/16/data/log` (log folder)