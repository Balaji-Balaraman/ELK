### UAT UM setup
A step-by-step guide for installing UM application. 

### Prerequisites
1. Admin privileges and SSH access to the server
1. Server should have internet access to be able to download and install packages
1. x86_64 or ARM64 Linux VM with minimum 4 GB RAM and 10GB disk space

### Steps to execute
1. Setup RHEL and Docker (from markdown_DO_setup_uat_rhel_docker.md file) on this VM.
1. Open required ports on the VM.
1. Setup Postgres and Restore the DB data
1. Setup NGINX and UM Application.

### Open required ports
1. `sudo su` (become sudo)
1. `firewall-cmd --list-ports` (see if the following are already open, in which case skip the remainder of this section)
1. `firewall-cmd --permanent --add-port=5643/tcp --add-port=443/tcp --add-port=8443/tcp --add-port=8089/tcp --zone=public`
1. `firewall-cmd --reload` (reload changes)
1. `firewall-cmd --list-ports` (validate) 


### Postgres Setup
1. `rm -rf /etc/dnf/vars/releasever` 
1. `dnf --disablerepo='*' remove 'rhui-azure-rhel9-eus'` (remove EUS repo)
1. `dnf --config='https://rhelimage.blob.core.windows.net/repositories/rhui-microsoft-azure-rhel9.config' install rhui-azure-rhel9` (add non EUS repo)
1. `yum clean all`
1. `dnf install https://download.postgresql.org/pub/repos/yum/reporpms/EL-9-x86_64/pgdg-redhat-repo-latest.noarch.rpm -y`(download & install PostgreSQL)
1. `dnf -qy module disable postgresql` (avoid conflicts with default PostgreSQL modules)
1. `dnf install -y postgresql16-server` (install DB)

### Configure DB
1. `mkdir -p /data/um_db/pgsql/16/data/`
1. `chown postgres:postgres /data/um_db/pgsql/16/data/`
1. `chmod 700 /data/um_db/pgsql/16/data/`
1. `su - postgres -c "/usr/pgsql-16/bin/initdb -D /data/um_db/pgsql/16/data/"` (run init script as postgres user)
1. `systemctl enable postgresql-16` (enable postgres service)
1. In file `/etc/systemd/system/multi-user.target.wants/postgresql-16.service` replace `/var/lib/pgsql/16/data/` against `Environment=PGDATA=` (~ line 29) variable to `/data/um_db/pgsql/16/data/`
1. `systemctl daemon-reload` (reload changes)
1. Update `/data/um_db/pgsql/16/data/postgresql.conf` 
   1. port 5643 (default is 5432)
   1. listen_addresses = '*'
   1. max_connections = 500
   1. timezone = 'Asia/Kolkata';
   1. log_timezone = 'Asia/Kolkata';
1. Update `/data/um_db/pgsql/16/data/pg_hba.conf` file
   1. Add the following three lines towards the end of the file (where other connection config is placed, 172.xx is docker network)
       1. `host    all             all             10.91.20.63/32          md5`
	   1. `host    all             all             172.19.0.0/16           md5`
	   1. `host    all             all             10.60.35.0/24           scram-sha-256`
1. `systemctl status postgresql-16` (check status and start)
1. `systemctl start postgresql-16` (check status and start)
1. `dnf install postgresql16-contrib -y` (install crypto package)
1. `ls /usr/pgsql-16/share/extension/pgcrypto.control` (verify it is installed)
1. `systemctl restart postgresql-16` (restart postgres)
1. `sudo -u postgres psql -p 5643` (login to postgres)
1. `CREATE EXTENSION pgcrypto;` (create crypto extension)
1. `SELECT gen_random_uuid();` (verify installation)
1. `SELECT * FROM pg_extension WHERE extname = 'pgcrypto';` (verify crypto's installation)
1. `\q` (exit postgres)

### Validate DB (from linux terminal not from within postgres)
1. `su - postgres -c "psql -p 5643 -c 'SHOW data_directory;'"` (should return 1 record)

## Attach password to postgres user
1. `sudo -u postgres psql -p 5643` (login to postgres)
1. `ALTER USER postgres WITH PASSWORD 'N!mbu$Dev2oz1'`;
1. Validate this user/password by logging in

## Create DB in Current VM
1. `sudo -u postgres psql -p 5643` (login to postgres)
1. `CREATE database nimbus;` (create the db)
1. `\q`(exit postgres)

## Create the following users and roles
1. `pg_dump -h 10.91.20.40 -p 5643 -U postgres -d nimbus --schema=user_management --exclude-table=user_management.user_logger > /data/user_management.dump` (User Management Schema with Data)
1. `pg_dump -h 10.91.20.40 -p 5643 -U postgres -d nimbus --schema=audit --schema-only > /data/audit_schema_only.dump` (Audit Schema without Data)
1. `pg_dump -h 10.91.20.40 -p 5643 -U postgres -d nimbus --schema=static_data > /data/static_data.dump` (static Data Schema with Data)
1. `pg_dump -h 10.91.20.40 -p 5643 -U postgres -d nimbus --schema=public --schema-only > /data/public_schema_only.dump` (Public Schema without Data)
1. `pg_dumpall -h 10.91.20.40 -p 5643 -U postgres --globals-only > /data/global_roles_dump.sql` (take user dump)
1. `psql -h localhost -p 5643 -U postgres -f /data/global_roles_dump.sql` (restore users - remove ones corresponding to postgres. It is already present)
    1. Note:- While restoring data dump, we might face some errors related to schemas/tables not present, these tables/schemas are not related to UM, and can be ignored.
1. `psql -h 127.0.0.1 -p 5643 -U postgres nimbus < /data/audit_schema_only.dump` (restore the Audit Schema dump)
1. `psql -h 127.0.0.1 -p 5643 -U postgres nimbus < /data/static_data.dump` (restore the Static Data schema data dump)
1. `psql -h 127.0.0.1 -p 5643 -U postgres nimbus < /data/public_schema_only.dump` (restore the Public Schema dump)
1. `psql -h 127.0.0.1 -p 5643 -U postgres nimbus < /data/user_management.dump` (restore the User Management data dump)

## Cleanup
1. `rm -rf /data/user_management.dump`
1. `rm -rf /data/audit_schema_only.dump`
1. `rm -rf /data/static_data.dump`
1. `rm -rf /data/public_schema_only.dump`
1. `rm -rf /data/global_roles_dump.sql`

## NGINX and UM Setup
### Pre-reqs (run under sudo)
1. `mkdir -p /nimbus/apps/api/usermanagement /nimbus/apps/keys/certificates/2025 /nimbus/apps/logs /nimbus/apps/api/usermanagement/config`
1. `touch /nimbus/apps/api/usermanagement/docker-compose.yml /nimbus/apps/api/usermanagement/nginx.conf /nimbus/apps/api/usermanagement/allowed_ip.conf /nimbus/apps/api/usermanagement/config/application.yaml /nimbus/apps/api/usermanagement/elasticapm.properties`
1. SCP the files from 10.91.20.59 (main nginx server) 
	1. Login into 10.91.20.59 as root (`sudo su`)
    1. `scp /nimbus/apps/certificates/2025/nac2025.crt chandu.vaddadi@northernarc.com#northernarc@10.91.20.63#northernarc@northernarc.ssh.cyberark.cloud:/home/nacl_pam_admin/`
	1. `scp /nimbus/apps/certificates/2025/nac2025.key chandu.vaddadi@northernarc.com#northernarc@10.91.20.63#northernarc@northernarc.ssh.cyberark.cloud:/home/nacl_pam_admin/`
	1. Exit out of 10.91.20.59
	1. Login into 10.91.20.63 (`sudo su`)
	1. `mkdir -p /nimbus/apps/keys/certificates/2025/'
	1. `mv /home/nacl_pam_admin/nac2025.* /nimbus/apps/keys/certificates/2025/` (move certs into right location)
1. Copy the content from markdown_DO_setup_uat_allowed_ips.md file into `/nimbus/apps/api/usermanagement/allowed_ip.conf`
1. Copy the following script into `/nimbus/apps/api/usermanagement/docker-compose.yml`
	<details>
		<summary>Click to expand</summary>
		
    ```
    services:
      npos-um-app:
        image: nexus.northernarc.com/npos/qa/api/partner-origination-user-management-api/usermanagement-npos-um-app:1.0.0
        environment:
          - TZ=Asia/Kolkata
        ports:
          - "6650"
        volumes:
          - /nimbus:/nimbus
    #      - /nimbus/apps/logs:/nimbus/apps/logs:ro
    #      - ./config/application.yaml:/nimbus/apps/api/usermanagement/config/application.yaml
    #      - ./elasticapm.properties:/nimbus/apps/api/usermanagement/elasticapm.properties    
        healthcheck:
          test: [ "CMD","curl","http://127.0.0.1:6650/um/actuator/health" ]
          interval: 10s
          timeout: 10s
          retries: 100
        deploy:
          replicas: 1
          resources:
            limits:
              cpus: '1.0'
              memory: 7G
        networks:
          - npos-um-network
        
      nginx:
        image: nexus.northernarc.com/nimbus.po.nginx:1.0.0
        environment:
          - TZ=Asia/Kolkata
        ports:
          - "80:80"
          - "443:443"
          # - "8443:8443"
        volumes:
          - /nimbus/apps/logs:/nimbus/apps/logs:ro
            #- /nimbus/apps/keys/certificates/2024:/nimbus/apps/keys/certificates/2024:ro
          - /nimbus/apps/keys/certificates/2025:/nimbus/apps/keys/certificates/2025:ro
          - /nimbus/apps/logs/nginx:/var/log/nginx
          - ./nginx.conf:/etc/nginx/nginx.conf:ro
          - ./allowed_ip.conf:/etc/nginx/conf.d/allowed_ip.conf:ro
        networks:
          - npos-um-network
            
    networks:
      npos-um-network:
        driver: bridge
        ipam:
          config:
            - subnet: "172.19.0.0/16"
   ```
   </details>
   
1. Copy the following script into /nimbus/apps/api/usermanagement/nginx.conf
	<details>
		<summary>Click to expand</summary>
		
    ```
    user nginx;
    worker_processes auto;  # Automatically adjust based on available CPU cores
    pid /run/nginx.pid;
    worker_rlimit_nofile 100000;  # Set the maximum number of open files

    # Include dynamic modules
    include /usr/share/nginx/modules/*.conf;

    events {
        worker_connections 10240;  # Set worker connections; 10,240 is often sufficient and safer
        multi_accept on;  # Accept multiple connections at once
        use epoll;  # Use epoll for better performance on Linux
    }

    http {
        # Basic Settings
        sendfile on;
        tcp_nopush on;
        tcp_nodelay on;
        types_hash_max_size 2048;

        include /etc/nginx/mime.types;
        default_type application/octet-stream;

        log_format json_combined escape=json '{'
            '"time_local":"$time_local",'
            '"remote_addr":"$remote_addr",'
            '"remote_port":"$remote_port",'
            '"request":"$request",'
            '"status":"$status",'
            '"body_bytes_sent":"$body_bytes_sent",'
            '"http_referer":"$http_referer",'
            '"http_user_agent":"$http_user_agent",'
            '"http_x_forwarded_for":"$http_x_forwarded_for",'
            '"request_time":"$request_time",'
            '"upstream_response_time":"$upstream_response_time",'
            '"upstream_connect_time":"$upstream_connect_time",'
            '"upstream_header_time":"$upstream_header_time",'
            '"upstream_addr":"$upstream_addr",'
            '"server_name":"$server_name",'
            '"connection":"$connection",'
            '"connection_requests":"$connection_requests",'
            '"bytes_received":"$request_length",'
            '"client_protocol":"$server_protocol",'
            '"host":"$host",'
            '"uri":"$uri",'
            '"args":"$args",'
            '"nginx_version":"$nginx_version"'
        '}';

        access_log /var/log/nginx/access.log json_combined;
        error_log /var/log/nginx/error.log crit;  # Log critical errors only

        # Gzip Settings
        gzip on;
        gzip_disable "msie6";
        gzip_vary on;
        gzip_proxied any;
        gzip_comp_level 6;  # Balance between compression level and performance
        gzip_buffers 16 8k;
        gzip_http_version 1.1;
        gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;

        # File Cache Settings
        open_file_cache max=200000 inactive=20s;
        open_file_cache_valid 30s;
        open_file_cache_min_uses 2;
        open_file_cache_errors on;

        # Timeouts and Limits
        client_body_timeout 10s;
        send_timeout 2s;
        reset_timedout_connection on;
        client_max_body_size 50M;  # Set a reasonable limit to prevent abuse
        proxy_connect_timeout 180s;
        proxy_read_timeout 180s; # Lowered from 600s for better performance
        proxy_send_timeout 180s;
        keepalive_timeout 180s;  # Increased to 180s to accomodate UM TAT
        keepalive_requests 1000; # Max no.of requests a single connection can serve

        upstream npos-um {
            least_conn;
            server npos-um-app:6650;
        }

    #    upstream npos-um-ui {
    #        least_conn;
    #        server npos-um-ui:8443;
    #    }

        # Map Configuration
        map $http_upgrade $connection_upgrade {
            default upgrade;
            '' close;
        }

        map $http_group_key $groupkey {
            default   $http_group_key;
            ""        "SERV_00000000001";
        }

        map $http_api_key $apikey {
            default   $http_api_key;
            ""        $http_x_api_key;
        }

        # HTTP Server Block for backend HTTP requests
        server {
            listen 80 default_server;
            listen [::]:80 default_server;
        server_name 10.91.20.63;
            root /usr/share/nginx/html;

            include /etc/nginx/default.d/*.conf;

            error_page 404 /404.html;
            error_page 500 502 503 504 /50x.html;

            location = /40x.html {}
            location = /50x.html {}

            location / {
            return 301 https://10.91.20.63:8443$request_uri;
            }

    #        location /um {
    #        return 301 https://10.91.20.63$request_uri;
    #        }

        }

    #     # HTTP Server Block for UI requests
    #     server {
    #         listen 8443 ssl http2 default_server;
    #         server_name 10.91.20.63;
    #     root /usr/share/nginx/html;
    # 
    #         # SSL Configuration
    #         ssl_certificate "/nimbus/apps/keys/certificates/2025/nac2025.crt";
    #         ssl_certificate_key "/nimbus/apps/keys/certificates/2025/nac2025.key";
    # 
    #         ssl_session_cache shared:SSL:10m;
    #         ssl_session_timeout 10m;
    #         ssl_prefer_server_ciphers on;
    #         ssl_protocols TLSv1.2;
    #         ssl_ciphers 'ECDHE-RSA-AES128-GCM-SHA256:AES128+EECDH:AES128+EDH';
    # 
    #         include /etc/nginx/default.d/*.conf;
    # 
    #         error_page 404 /404.html;
    #         location = /40x.html {}
    # 
    #         error_page 500 502 503 504 /50x.html;
    #         location = /50x.html {}
    # 
    #     location /logs/ {
    #             root /nimbus/apps/logs;
    #             autoindex on;
    #             allow all; # Restrict to internal IPs (optional)
    #             deny all;             # Deny all others
    #         }
    # 
    #         location /usermanagement {
    #            proxy_pass http://npos-um-ui;
    #            proxy_set_header Host $host;
    #            proxy_set_header X-Real-IP $remote_addr;
    #            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    #            proxy_set_header X-Forwarded-Proto $scheme;
    #         }
    # 
    #         location /ui-props {
    #             proxy_pass http://npos-um-ui;
    #             proxy_set_header Host $host;
    #             proxy_set_header X-Real-IP $remote_addr;
    #             proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    #             proxy_set_header X-Forwarded-Proto $scheme;
    #         }
    #     }

        # HTTPS Server Block
        server {
            listen 443 ssl http2 default_server;
            server_name 10.91.20.63;
            root /usr/share/nginx/html;

            ssl_certificate "/nimbus/apps/keys/certificates/2025/nac2025.crt";
            ssl_certificate_key "/nimbus/apps/keys/certificates/2025/nac2025.key";
            ssl_session_cache shared:SSL:10m;
            ssl_session_timeout 10m;
            ssl_prefer_server_ciphers on;
            ssl_protocols TLSv1.2;
            ssl_ciphers 'ECDHE-RSA-AES128-GCM-SHA256:AES128+EECDH:AES128+EDH';

            # proxy_set_header X-Forwarded-Proto https;

            include /etc/nginx/default.d/*.conf;

            error_page 404 /404.html;
            error_page 500 502 503 504 /50x.html;

            location = /40x.html {}
            location = /50x.html {}

            include /etc/nginx/conf.d/allowed_ip.conf;
            add_header Set-Cookie "Path=/; HttpOnly; Secure";
            add_header X-XSS-Protection "1; mode=block";
            add_header X-Content-Type-Options "nosniff";
            add_header X-Frame-Options "DENY";
            add_header Content-Security-Policy "default-src 'self';";
            location ~* "(eval())"  { return 404; }
            location ~* "([a-z0-9]{2000})" { return 404; }
            location ~* "(javascript:)(.*)(;)"  { return 404; }
            location ~* "(base64_encode)(.*)(())"  { return 404; }
            location ~* "(GLOBALS|REQUEST)(=|[|]%)"  { return 404; }
            location ~* "(<|%3C).*script.*(>|%3)" { return 404; }
            location ~* "(boot.ini|etc/passwd|self/environ)" { return 404; }
            location ~* "(thumbs?(_editor|open)?|tim(thumb)?).php" { return 404; }
            location ~* "(')(.*)(drop|insert|md5|select|union)" { return 404; }
            location ~* "(https?|ftp|php):/" { return 404; }
            location ~* "(='|=%27|/'/?)." { return 404; }
            #location ~* "/(=|$&|_mm|(wp-)?config.|cgi-|etc/passwd|muieblack)" { return 404; }
            location ~* "/(=|$&|_mm|(wp-)?cgi-|etc/passwd|muieblack)" { return 404; }
            location ~* "(&pws=0|_vti_|(null)|{$itemURL}|echo(.*)kae|etc/passwd|eval(|self/environ))" { return 404; }
            location ~* "\.(aspx?|bash|bak?|cfg|cgi|dll|exe|git|hg|ini|jsp|mdb|sql|svn|swp|tar|rdf)$" { return 404; }
            #location ~* ".(aspx?|bash|bak?|cfg|cgi|dll|exe|git|hg|ini|jsp|log|mdb|out|sql|svn|swp|tar|rdf)$" { return 404; }
            location ~* "/(^$|mobiquo|phpinfo|shell|sqlpatch|thumb|thumb_editor|thumbopen|timthumb|webshell).php" { return 404; }

            set $block_sql_injections 0; 
            if ($query_string ~ "(union.*select.*)") { set $block_sql_injections 1; }
            if ($query_string ~ "union.*all.*select.*") { set $block_sql_injections 1; }
            if ($query_string ~ "concat.*") { set $block_sql_injections 1; }
            if ($block_sql_injections = 1) { return 404; }
            #
            set $block_file_injections 0;
            if ($query_string ~ "[a-zA-Z0-9_]=http://") { set $block_file_injections 1; }
            if ($query_string ~ "[a-zA-Z0-9_]=(\.\./)+") { set $block_file_injections 1; }
            if ($query_string ~ "[a-zA-Z0-9_]=/([a-z0-9_.]//?)+") { set $block_file_injections 1; }
            if ($block_file_injections = 1) { return 404; }
            #
            set $block_common_exploits 0;
            if ($query_string ~ "(<|%3C).*script.*(>|%3E)") { set $block_common_exploits 1; }
            if ($query_string ~ "GLOBALS(=|[|%[0-9A-Z]{0,2})") { set $block_common_exploits 1; }
            if ($query_string ~ "_REQUEST(=|[|%[0-9A-Z]{0,2})") { set $block_common_exploits 1; }
            if ($query_string ~ "proc/self/environ") { set $block_common_exploits 1; }
            if ($query_string ~ "mosConfig_[a-zA-Z_]{1,21}(=|%3D)") { set $block_common_exploits 1; }
            if ($query_string ~ "base64_(en|de)code(.*)") { set $block_common_exploits 1; }
            if ($block_common_exploits = 1) { return 404; }
            #
            set $block_spam 0;
            if ($query_string ~ "b(ultram|unicauca|valium|viagra|vicodin|xanax|ypxaieo)b") { set $block_spam 1; }
            if ($query_string ~ "b(erections|hoodia|huronriveracres|impotence|levitra|libido)b") { set $block_spam 1; }
            if ($query_string ~ "b(ambien|bluespill|cialis|cocaine|ejaculation|erectile)b") { set $block_spam 1; }
            if ($query_string ~ "b(lipitor|phentermin|pro[sz]ac|sandyauer|tramadol|troyhamby)b") { set $block_spam 1; }
            if ($block_spam = 1) { return 404; }
            #
            set $block_user_agents 0;
            if ($http_user_agent ~ "Indy Library") { set $block_user_agents 1; }
            if ($http_user_agent ~ "libwww-perl") { set $block_user_agents 1; }
            if ($http_user_agent ~ "GetRight") { set $block_user_agents 1; }
            if ($http_user_agent ~ "GetWeb!") { set $block_user_agents 1; }
            if ($http_user_agent ~ "Go!Zilla") { set $block_user_agents 1; }
            if ($http_user_agent ~ "Download Demon") { set $block_user_agents 1; }
            if ($http_user_agent ~ "Go-Ahead-Got-It") { set $block_user_agents 1; }
            if ($http_user_agent ~ "TurnitinBot") { set $block_user_agents 1; }
            if ($http_user_agent ~ "GrabNet") { set $block_user_agents 1; }
            if ($block_user_agents = 1) { return 404; }
        
            # Commenting out for `update` for `initiateBatch - apiType` parameter    
            # if ($query_string ~* "(union|select|insert|update|delete|drop|truncate|information_schema|;|--)") {
            #     return 404;
            # }

            if ($query_string ~* "(union|select|insert|delete|drop|truncate|information_schema|;|--)") {
                return 404;
            }

            #Detect SQL Comment Sequences
            if ($query_string ~* "(/\*!?|\*/|[';]--|--[\s\r\n\v\f]|(?:--[^-]*?-)|([^\-&])#.*?[\s\r\n\v\f]|;?\\x00)"){
             return 404;
            }
            # String Termination/Statement Ending Injection prevention
            if ($query_string ~* "(^[\"'`´’‘;]+|[\"'`´’‘;]+$)"){
                return 404;
            }
            #SQL Hex Evasion Methods
            if ($query_string ~* "(?i:(?:\A|[^\d])0x[a-f\d]{3,}[a-f\d]*)"){
                return 404;
            }
            #SQL Operators
            if ($query_string ~* "(?i:(\!\=|\&\&|\|\||>>|<<|>=|<=|<>|<=>|xor|rlike|regexp|isnull)|(?:not\s+between\s+0\s+and)|(?:is\s+null)|(like\s+null)|(?:(?:^|\W)in[+\s]*\([\s\d\"]+[^()]*\))|(?:xor|<>|rlike(?:\s+binary)?)|(?:regexp\s+binary))"){
                return 404;
            }
            location ~* \.(htpasswd|git|svn|env|ini|log|conf)$ {
                return 404;
            }

            location /nginx_status {
                stub_status;
             #   allow 127.0.0.1;
            allow all;           # Only allow requests from localhost
               # deny none;          # Deny all other requests
            }


            location /um {
                proxy_pass http://npos-um;
                proxy_set_header Host $host;
                proxy_set_header X-Real-IP $remote_addr;
                proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
                proxy_set_header X-Forwarded-Proto $scheme;
                proxy_set_header X-Forwarded-Host $host;
                # proxy_set_header GROUP-KEY $groupkey;
            # proxy_set_header API-KEY $apikey;
            }
        }
    }
    ```
	</details>
1. Copy the following script into /nimbus/apps/api/usermanagement/config/application.yaml
	<details>
		<summary>Click to expand</summary>
		
   ```
    b2c:
        app:
            token:
                url: https://login.microsoftonline.com/northernarcb2c.onmicrosoft.com/oauth2/v2.0/token
        cert:
            keys: https://northernarcb2c.b2clogin.com/northernarcb2c.onmicrosoft.com/discovery/v2.0/keys?p=
        client: d9312776-e8a9-4d66-9931-de7fee72f5b6
        client.secret: zHQ8Q~mAZ3dtr52gx~6eGVOrt0JDBJusAGKUsaRM
        client.url: https://northernarcb2c.b2clogin.com/northernarcb2c.onmicrosoft.com/oauth2/v2.0/token?p=
        graph:
            url: https://graph.microsoft.com/v1.0
            beta:
                url: https://graph.microsoft.com/beta
        idp:
            name: https://northernarcb2c.b2clogin.com
        tenant:
            name: https://northernarcb2c.onmicrosoft.com
        signin-policy: b2c_1_signin
        dom:
            signin-policy: b2c_1a_signin_signup
    nac:
        office365:
            token:
                url: https://login.microsoftonline.com/collaborate365.onmicrosoft.com/oauth2/v2.0/token
            client: 778aa161-0c77-4a25-9b54-deaf4cb4570f
            client.secret: JSP8Q~FtozxpHQ7tuj4gfx2iFL8JeF1tFFqyoc7n        
    adfs:
        token:
            url: https://sts.northernarc.com/adfs/oauth2/token
        keys:
            url: https://sts.northernarc.com/adfs/discovery/keys    
    http:
        client:
            connection:
                hostname: https://sts.northernarc.com
                idle:
                    wait:
                        time: 20000
                keepalive:
                    time: 20000
                localhost:
                    max: 100
                max: 300
                request:
                    timeout: 20000
                route:
                    max: 100
                socket:
                    timeout: 20000
                timeout: 20000
                tlsversions: TLSv1,TLSv1.1,TLSv1.2
    jasypt:
        encryptor:
            password: Nimbus
            algorithm: PBEWithMD5AndDES
            iv-generator-classname: org.jasypt.iv.NoIvGenerator
    logging:
        level:
            org:
                springframework:
                    web: INFO
    management:
        security:
            enabled: false
    nimbus:
        secret:
            key: ewogICJvcmlnaW5hdG9yX3NlY3JldF9rZXkiOiAiZWMzOGRjYWQtMjA0OC00ZmE2LTgyMmUtNjJmMzQzYjRmZmIzIgp9
        app:
            eo:
                base:
                    url: https://ENTITY-ONBOARDING/eo/api
                stage:
                    info: /stage/{entityId}/{sectorId}
            id: USER_MANAGEMENT
            notification:
                url: https://NOTIFICATION/notifications/api
            um:
                base:
                    #url: https://USER-MANAGEMENT/um/api    
                    url: https://DOSTAGE-UM/um/api
                team:
                    info: /team
                userinfo:
                    by:
                        company:
                            url: /user/team/company/{companyId}/
                        team:
                            url: /user/role/{roleId}/{appId}
                        userId:
                            url: /user/id/{userId}
                    email: /user/userinfo/email/{email}
                    url: /user/token/app/{appId}
            structuring:
                url: https://STRUCTURING/structuring/api
            ir:
                base:
                    url: https://INVESTOR-RELATIONS/ir/api
        limitnote:
            ceo:
                email: PRIYAN.P@NORTHERNARC.COM
        logging:
            ext:
                enabled: false
                url: 'http://10.91.22.196:8090'
        mail:
            enabled: false
            request:
                user:
                    creation: C.PRITHVI@NORTHERNARC.COM,C.PRIYESH@NORTHERNARC.COM
        profile:
            picture:
                path: /nimbus/apps/api/usermanagement/profilepics
        signin:
            url: '{dom:''https://nimbusdevnew.northernarc.com:8443/digital-onboarding/''}'
        um:
            unlock:
                timeout: 120
    server:
     port: 6650
     servlet:
         context-path: /um
     error:
         include-message: always    
     ssl:
         enabled: false
         key-store: /data/nimbus/keys/stsnac.pfx
         key-store-password: Micro@123
         keyStoreType: PKCS12
         protocol: TLS
    spring:
        application:
            name: DOSTAGE-UM
        boot:
            admin:
                client:
                    name: User Management
                    url: http://localhost:6650
        datasource:
            driver-class-name: org.postgresql.Driver
            hikari:
                idleTimeout: 10000
                maxLifetime: 600000
                maximumPoolSize: 2
                minimumIdle: 1
            initialize: true
            password: ENC(1J+XcDZYy1ctkvqb+3I/cJmn5HtA+Fva)
            url: jdbc:postgresql://10.91.20.63:5643/nimbus
            username: nimbus_app_user
        jpa:
            database-platform: org.hibernate.dialect.PostgreSQL9Dialect
            properties:
                hibernate:
                    temp:
                        use_jdbc_metadata_defaults: false
            show-sql: false
        main:
            allow-bean-definition-overriding: true
        mvc:
            pathmatch:
                matching-strategy: ANT_PATH_MATCHER
    syncope:
        url: https://10.91.20.63:6645/syncope/rest/
    um:
        temp:
            base:
                dir: /nimbus/apps/api/usermanagement/attachments/
    originator:
        email: originator@northernarc.com
        access:
            key: eyJ1c2VybmFtZSI6Im9yaWdpbmF0b3JAbm9ydGhlcm5hcmMuY29tIiwicGFzc3dvcmQiOiJUb2RheUAxMjMiLCJjbGllbnRfaWQiOiI0NTMyZTU1OC02YzBiLTRmZGEtYWM2Ni0wNWMzMTY5MTA3MjYifQ==
    eureka:
      client:
        registerWithEureka: true
        fetchRegistry: true
        serviceUrl:
          defaultZone: http://localhost:8761/eureka/eureka/
      instance:
        hostname: localhost
        preferIpAddress: true
        secure-port: 443
        secure-port-enabled: true
        
    swagger:
        username: Admin
        password: ENC(5JC3Y1b1hyI1Hr2RB0kOdJTkyilFqWuY)
    environment:
        base:
            url: 10.91.20.63
    public:
        template:
            url: https://nimbus.northernarc.com/email-confirmation.html
    reportingManager:
      email:
        enable: false
    portal:
        originator:
            url: https://originatorstage.northernarc.com/
        investor:
            url: https://investorstage.northernarc.com/
        nimbus:
            url: https://stage.northernarc.com:8443/nimbus/
        investor-relations:
            url: https://stage.northernarc.com:5678/investor-relations/#/
    ad:
        clientId: be0ec5e6-e65b-4629-8efa-b815db112859
        clientSecret: ab78f529-978e-4e27-aeb2-dca3342e36cc
        tenantId: 9815c4a2-2c8b-40d1-87af-75e5365e197c
        secretValue: .ro8Q~U8tLRp5OmIgWHuCGP9qPGSKJv431xM3cyG
        token: https://login.microsoftonline.com/9815c4a2-2c8b-40d1-87af-75e5365e197c/oauth2/v2.0/token
        scope: "api://be0ec5e6-e65b-4629-8efa-b815db112859/Read"
        contentType: application/x-www-form-urlencoded
        grantType: authorization_code
        keys:
            url: https://login.microsoftonline.com/9815c4a2-2c8b-40d1-87af-75e5365e197c/discovery/v2.0/keys 
   ```
	</details>

1. Copy the following script into /nimbus/apps/api/usermanagement/elasticapm.properties
	<details>
		<summary>Click to expand</summary>
		
    ```
    service_name=PO-STAGE
    server_urls=http://10.91.20.65:8200
    profiling_inferred_spans_enabled=true
    log_level=INFO
    environment=STAGE
    secret_token=Nimbus@2K24
    ```  
	</details>
### Boot up
1. `docker ps -a`
1. `docker compose down` (stop)
1. `docker compose up -d` (start)
1. `docker compose restart` (restart)
1. `docker logs -f <container-name>` (logs)

### Clear .vault reference from Postgres (in case it is inherited)
In case the following error is seen in docker logs "Error occurred in decrypt function for value_string: 1yhXxh6SIerwh0ofknFBqSjggKK8WmgKSuCoPEy1lPg= - Error: function decrypt_iv(bytea, bytea, bytea, character varying) does not exist" then do the following.
1. `sudo -u postgres psql -p 5643` (login to postgres)
1. `\c nimbus;` (switch to nimbus DB)
1. `CREATE EXTENSION pgcrypto;` (create pgcrypto extension)

Now find the oid corresponding to the entry in pg_proc table and delete it
1. `select pronamespace, prosrc ,oid from pg_proc where proname = 'config_from_vault';`
1. `DELETE FROM pg_catalog.pg_proc WHERE "oid"=<put correct oid from above query>;`

Now create the tables and set permissions
1. `CREATE SCHEMA config AUTHORIZATION postgres;`
1. 
    ```
	CREATE TABLE config.property_mapper ( 
		id serial4 NOT NULL,
		"key" varchar(255) NOT NULL,
		value varchar(255) NULL,
		created_by varchar(255) NULL,
		created_date timestamp NULL,
		last_modified_by varchar(255) NULL,
		last_modified_date timestamp NULL,
		property_name varchar(255) NOT NULL,
		CONSTRAINT property_mapper_pkey PRIMARY KEY (id)
	);
	```
1. `GRANT ALL ON SCHEMA config TO postgres;`
1. `GRANT USAGE ON SCHEMA config TO nimbus_app_user;`
1. `ALTER TABLE config.property_mapper OWNER TO postgres;`
1. `GRANT ALL ON TABLE config.property_mapper TO postgres;`
1. `GRANT UPDATE, INSERT, DELETE, SELECT ON TABLE config.property_mapper TO nimbus_app_user;`
1. The SECRET_KEY should be available in `/var/lib/pgsql/.vault`
	```
	INSERT INTO config.property_mapper (id, "key", value, created_by, created_date, last_modified_by, last_modified_date, property_name)
	VALUES 
	(1, 'ALGO', 'aes', NULL, NULL, NULL, NULL, 'PI_ENCRYPT'),
	(2, 'SECRET_KEY', 'F2388451B0951234', NULL, NULL, NULL, NULL, 'PI_ENCRYPT'),
	(3, 'ENCODE', 'BASE64', NULL, NULL, NULL, NULL, 'PI_ENCRYPT'),
	(4, 'INITIALIZATION VECTOR', '0000000000000000', NULL, NULL, NULL, NULL, 'PI_ENCRYPT');
	```
1. 
	```
	CREATE OR REPLACE FUNCTION public.decrypt(value_string text)
	RETURNS text
	LANGUAGE plpgsql
	AS $function$
	DECLARE
		algo VARCHAR;
		encode_type VARCHAR;
		secret_key VARCHAR;
		result_json TEXT;
		vector VARCHAR;
	BEGIN

	-- Retrieve encryption configuration from config.property_mapper

	SELECT value INTO algo FROM config.property_mapper WHERE "key" = 'ALGO' AND property_name = 'PI_ENCRYPT';
	SELECT value INTO encode_type FROM config.property_mapper WHERE "key" = 'ENCODE' AND property_name = 'PI_ENCRYPT';
	SELECT value INTO secret_key FROM config.property_mapper WHERE "key" = 'SECRET_KEY' AND property_name = 'PI_ENCRYPT';
	SELECT value INTO vector FROM config.property_mapper WHERE "key" = 'INITIALIZATION VECTOR' AND property_name = 'PI_ENCRYPT';

	-- Perform decryption using retrieved values

	SELECT convert_from(decrypt_iv(decode(value_string, encode_type)::bytea, secret_key::bytea, vector::bytea, algo), 'UTF8')
	INTO result_json;
		RETURN result_json;
	EXCEPTION
		WHEN OTHERS THEN
			RAISE EXCEPTION 'Error occurred in decrypt function for value_string: % - Error: %', value_string, SQLERRM;
			RETURN NULL;
	END;
	$function$;
	```
1. `ALTER FUNCTION public.decrypt(text) OWNER TO nimbus_app_user;`
1. `GRANT ALL ON FUNCTION public.decrypt(text) TO nimbus_app_user;`
1. `\q` (exit from postgres)
1. `rm -rf /var/lib/pgsql/.vault` (clear the .vault file)

### Test & Validate
1. Check the container status using `docker compose ps -a`
1. Check the container logs using `docker compose logs -f`
