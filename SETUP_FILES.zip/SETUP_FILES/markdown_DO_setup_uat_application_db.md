## Setting Up `application.yaml` for Partner Origination DB

Follow these steps to set up the `application.yaml` file for the **Partner Origination Database**.

---

## 1. Create the Required Directory under SUDO access
Ensure that the directory exists; if not, create it using the following command:

```sh
sudo su
```

```sh
mkdir -p /nimbus/apps/api/partner-origination-db/config
```

## 2. Create the `application.yaml` File
Run the following command to create an empty `application.yaml` file:

```sh
sudo touch /nimbus/apps/api/partner-origination-db/config/application.yaml
```

## 3. Copy Contents from Bitbucket Repository

```sh
sudo vi /nimbus/apps/api/partner-origination-db/config/application.yaml
```

```sh
jasypt:
  encryptor:
    password: Nimbus
logging:
  level:
    org:
      springframework:
        web: INFO
nimbus:
  app:
    id: NPOS_DB_SCRIPTS
  mail:
    enabled: false
spring:
  datasource:
    driver-class-name: org.postgresql.Driver
    initialize: true
    url: jdbc:postgresql://10.91.20.57:5643/nimbus_credit_processor
    username: nimbus_app_user
    password: ENC(hf19LovWizKD4+/AADyCVNp1SnZNnYRB)
  jpa:
    properties:
      hibernate:
        dialect: org.hibernate.dialect.PostgreSQLDialect
        temp:
          use_jdbc_metadata_defaults: false
    show-sql: true

```

## 4. Verify the Changes
To confirm that the file has been updated correctly, run:

```sh
cat /nimbus/apps/api/partner-origination-db/config/application.yaml
```



