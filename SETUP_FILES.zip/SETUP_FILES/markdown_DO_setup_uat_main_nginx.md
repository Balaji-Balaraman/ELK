### UAT nginx setup (main instance)
A step-by-step guide for installing nginx. 

### Prerequisites
1. Admin privileges and SSH access to the server
1. Server should have internet access to be able to download and install packages
1. x86_64 or ARM64 Linux VM with minimum 4 GB RAM and 10GB disk space

### Pre-reqs (run under sudo)
1. `mkdir -p /nimbus/apps/nginx /nimbus/apps/certificates/2025 /nimbus/apps/logs/nginx`
1. `touch /nimbus/apps/nginx/docker-compose.yml /nimbus/apps/nginx/nginx.conf /nimbus/apps/nginx/allowed_ip.conf`
1. Copy ***nac2025.crt*** & ***nac2025.key*** from certificates-2025 folder in Sharepoint to /nimbus/apps/certificates/2025 on 10.91.20.59 (current VM)
1. Copy the contents from ***markdown_DO_setup_uat_allowed_ips.md*** file into ***allowed_ip.conf***
1. Copy the following script into ***docker-compose.yml***
	<details>
		<summary>Click to expand</summary>

    ```
	services:
	  nginx:
	   image: nexus.northernarc.com/nimbus.po.nginx:1.0.0
		 ports:
		   - "8443:8443"
		   - "80:80"
		   - "443:443"
		 volumes:
		   - /nimbus/apps/certificates/2025:/nimbus/apps/certificates/
		   - /nimbus/apps/certificates/2025:/nimbus/apps/certificates/2025/
		   - /nimbus/apps/nginx/allowed_ip.conf:/etc/nginx/conf.d/allowed_ip.conf
		   - /nimbus/apps/logs/nginx:/var/log/nginx
		   - ./nginx.conf:/etc/nginx/nginx.conf:ro
	   networks:
		   - api-network

	networks:
		api-network:
		   driver: bridge
   ```
	</details>
1. Copy the following script into ***nginx.conf***
	<details>
		<summary>Click to expand</summary>
		
    ```
	user nginx;
	worker_processes auto;  # Automatically adjust based on available CPU cores
	pid /run/nginx.pid;
	worker_rlimit_nofile 100000;  # Set the maximum number of open files

	# Include dynamic modules
	include /usr/share/nginx/modules/*.conf;

	events {
		worker_connections 10240;  # Set worker connections; 10,240 is often sufficient and safer
		multi_accept on;  # Accept multiple connections at once
		use epoll;  # Use epoll for better performance on Linux
	}

	http {

	# Basic Settings
		sendfile on;
		tcp_nopush on;
		tcp_nodelay on;
		types_hash_max_size 2048;
		
		include /etc/nginx/mime.types;
		default_type application/octet-stream;

		log_format json_combined escape=json '{'
		'"time_local":"$time_local",'
		  '"remote_user":"$remote_user",'
		'"remote_addr":"$remote_addr",'
		'"remote_port":"$remote_port",'
		'"request":"$request",'
		'"status":"$status",'
		'"body_bytes_sent":"$body_bytes_sent",'
		'"http_referer":"$http_referer",'
		'"http_user_agent":"$http_user_agent",'
		'"http_x_forwarded_for":"$http_x_forwarded_for",'
		'"request_time":"$request_time",'
		'"upstream_response_time":"$upstream_response_time",'
		'"upstream_connect_time":"$upstream_connect_time",'
		'"upstream_header_time":"$upstream_header_time",'
		'"upstream_addr":"$upstream_addr",'
		'"server_name":"$server_name",'
		'"connection":"$connection",'
		'"connection_requests":"$connection_requests",'
		'"bytes_received":"$request_length",'
		'"client_protocol":"$server_protocol",'
		'"host":"$host",'
		'"uri":"$uri",'
		'"args":"$args",'
		'"nginx_version":"$nginx_version"'
		'}';

		access_log /var/log/nginx/access.log json_combined;
		error_log /var/log/nginx/error.log crit;  # Log critical errors only

		# Gzip Settings
		gzip on;
		gzip_disable "msie6";
		gzip_vary on;
		gzip_proxied any;
		gzip_comp_level 6;  # Balance between compression level and performance
		gzip_buffers 16 8k;
		gzip_http_version 1.1;
		gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;

		# File Cache Settings
		open_file_cache max=200000 inactive=20s;
		open_file_cache_valid 30s;
		open_file_cache_min_uses 2;
		open_file_cache_errors on;

		# Timeouts and Limits
		client_body_timeout 180s;
		send_timeout 180s;
		reset_timedout_connection on;
		client_max_body_size 50M;  # Set a reasonable limit to prevent abuse
		proxy_connect_timeout 180s;
		proxy_read_timeout 180s; # Lowered from 600s for better performance
		proxy_send_timeout 180s;
		keepalive_timeout 180s;  # Increased to 180s to accomodate UM TAT
		keepalive_requests 1000; # Max no.of requests a single connection can serve
		
		upstream po-backend-disbursement {
			least_conn;
			server 10.91.20.60:443;
		}

		upstream po-backend {
			least_conn;
			server 10.91.20.61:443;
		}
		
		upstream po-backend-status {
			least_conn;
			server 10.91.20.62:443;
		}

		map $http_group_key $groupkey {
			default   $http_group_key;
			""        "SERV_00000000001";
		}

		map $http_api_key $apikey {
			default   $http_api_key;
			""        $http_x_api_key;
		}
		
		

		# HTTP Server Block
		server {

			listen 80 default_server;
			listen [::]:80 default_server;
			server_name 10.91.20.59;
			root /usr/share/nginx/html;

			include /etc/nginx/default.d/*.conf;

			error_page 404 /404.html;
			error_page 500 502 503 504 /50x.html;

			location = /40x.html {}
			location = /50x.html {}
			
			location / {
				return 301 https://10.91.20.59:8443$request_uri;
			}


		}


		# HTTP Server Block
		server {
			listen 8443 ssl http2 default_server;
			server_name 10.91.20.59;
			root /usr/share/nginx/html;

			# SSL Configuration
			#ssl_certificate /nimbus/apps/certificates/northernarc-com-chain.crt;
			ssl_certificate /nimbus/apps/certificates/2025/nac2025.crt;
			#ssl_certificate_key /nimbus/apps/certificates/NAC2024.key;
			ssl_certificate_key /nimbus/apps/certificates/2025/nac2025.key;

			ssl_session_cache shared:SSL:10m;
			ssl_session_timeout 10m;
			ssl_prefer_server_ciphers on;
			ssl_protocols TLSv1.2;
			ssl_ciphers 'ECDHE-RSA-AES128-GCM-SHA256:AES128+EECDH:AES128+EDH';

			include /etc/nginx/default.d/*.conf;

			error_page 404 /404.html;
			location = /40x.html {}

			error_page 500 502 503 504 /50x.html;
			location = /50x.html {}

			
			location /partner-origination {
				proxy_pass https://po-backend/partner-origination;
				proxy_set_header API-KEY $apikey;
				  proxy_set_header GROUP-KEY $groupkey;
				proxy_set_header Host $host;
				proxy_set_header X-Real-IP $remote_addr;
				proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
				proxy_set_header X-Forwarded-Proto $scheme;
			}
			
			location /partner-origination-processor {
				proxy_pass https://po-backend-disbursement/partner-origination-processor;
				proxy_set_header Host $host;
				proxy_set_header X-Real-IP $remote_addr;
				proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
				proxy_set_header X-Forwarded-Proto $scheme;
			}
			
			location / {
				return 301 https://10.91.20.59$request_uri;
			}
		}

		# HTTPS Server Block
		server {
			listen 443 ssl http2 default_server;
			root /usr/share/nginx/html;
			server_name 10.91.20.59;

			# SSL Configuration
			#ssl_certificate /nimbus/apps/certificates/northernarc-com-chain.crt;
			ssl_certificate /nimbus/apps/certificates/nac2025.crt;
			#ssl_certificate_key /nimbus/apps/certificates/NAC2024.key;
			ssl_certificate_key /nimbus/apps/certificates/nac2025.key;

			ssl_session_cache shared:SSL:10m;
			ssl_session_timeout 10m;
			ssl_prefer_server_ciphers on;
			ssl_protocols TLSv1.2;
			ssl_ciphers 'ECDHE-RSA-AES128-GCM-SHA256:AES128+EECDH:AES128+EDH';

			include /etc/nginx/default.d/*.conf;

			error_page 404 /404.html;
			error_page 500 502 503 504 /50x.html;

			location = /40x.html {}
			location = /50x.html {}
		  
			include /etc/nginx/conf.d/allowed_ip.conf;
			add_header Set-Cookie "Path=/; HttpOnly; Secure";
			add_header X-XSS-Protection "1; mode=block";
			add_header X-Content-Type-Options "nosniff";
			add_header X-Frame-Options "DENY";
			add_header Content-Security-Policy "default-src 'self';";
			location ~* "(eval())"  { return 404; }
			location ~* "([a-z0-9]{2000})" { return 404; }
			location ~* "(javascript:)(.*)(;)"  { return 404; }
			location ~* "(base64_encode)(.*)(())"  { return 404; }
			location ~* "(GLOBALS|REQUEST)(=|[|]%)"  { return 404; }
			location ~* "(<|%3C).*script.*(>|%3)" { return 404; }
			location ~* "(boot.ini|etc/passwd|self/environ)" { return 404; }
			location ~* "(thumbs?(_editor|open)?|tim(thumb)?).php" { return 404; }
			location ~* "(')(.*)(drop|insert|md5|select|union)" { return 404; }
			location ~* "(https?|ftp|php):/" { return 404; }
			location ~* "(='|=%27|/'/?)." { return 404; }
			#location ~* "/(=|$&|_mm|(wp-)?config.|cgi-|etc/passwd|muieblack)" { return 404; }
			location ~* "/(=|$&|_mm|(wp-)?cgi-|etc/passwd|muieblack)" { return 404; }
			location ~* "(&pws=0|_vti_|(null)|{$itemURL}|echo(.*)kae|etc/passwd|eval(|self/environ))" { return 404; }
			location ~* "\.(aspx?|bash|bak?|cfg|cgi|dll|exe|git|hg|ini|jsp|mdb|sql|svn|swp|tar|rdf)$" { return 404; }
			#location ~* ".(aspx?|bash|bak?|cfg|cgi|dll|exe|git|hg|ini|jsp|log|mdb|out|sql|svn|swp|tar|rdf)$" { return 404; }
			location ~* "/(^$|mobiquo|phpinfo|shell|sqlpatch|thumb|thumb_editor|thumbopen|timthumb|webshell).php" { return 404; }
		  
			set $block_sql_injections 0; 
			if ($query_string ~ "(union.*select.*)") { set $block_sql_injections 1; }
			if ($query_string ~ "union.*all.*select.*") { set $block_sql_injections 1; }
			if ($query_string ~ "concat.*") { set $block_sql_injections 1; }
			if ($block_sql_injections = 1) { return 404; }
			#
			set $block_file_injections 0;
			if ($query_string ~ "[a-zA-Z0-9_]=http://") { set $block_file_injections 1; }
			if ($query_string ~ "[a-zA-Z0-9_]=(\.\./)+") { set $block_file_injections 1; }
			if ($query_string ~ "[a-zA-Z0-9_]=/([a-z0-9_.]//?)+") { set $block_file_injections 1; }
			if ($block_file_injections = 1) { return 404; }
			#
			set $block_common_exploits 0;
			if ($query_string ~ "(<|%3C).*script.*(>|%3E)") { set $block_common_exploits 1; }
			if ($query_string ~ "GLOBALS(=|[|%[0-9A-Z]{0,2})") { set $block_common_exploits 1; }
			if ($query_string ~ "_REQUEST(=|[|%[0-9A-Z]{0,2})") { set $block_common_exploits 1; }
			if ($query_string ~ "proc/self/environ") { set $block_common_exploits 1; }
			if ($query_string ~ "mosConfig_[a-zA-Z_]{1,21}(=|%3D)") { set $block_common_exploits 1; }
			if ($query_string ~ "base64_(en|de)code(.*)") { set $block_common_exploits 1; }
			if ($block_common_exploits = 1) { return 404; }
			#
			set $block_spam 0;
			if ($query_string ~ "b(ultram|unicauca|valium|viagra|vicodin|xanax|ypxaieo)b") { set $block_spam 1; }
			if ($query_string ~ "b(erections|hoodia|huronriveracres|impotence|levitra|libido)b") { set $block_spam 1; }
			if ($query_string ~ "b(ambien|bluespill|cialis|cocaine|ejaculation|erectile)b") { set $block_spam 1; }
			if ($query_string ~ "b(lipitor|phentermin|pro[sz]ac|sandyauer|tramadol|troyhamby)b") { set $block_spam 1; }
			if ($block_spam = 1) { return 404; }
			#
			set $block_user_agents 0;
			if ($http_user_agent ~ "Indy Library") { set $block_user_agents 1; }
			if ($http_user_agent ~ "libwww-perl") { set $block_user_agents 1; }
			if ($http_user_agent ~ "GetRight") { set $block_user_agents 1; }
			if ($http_user_agent ~ "GetWeb!") { set $block_user_agents 1; }
			if ($http_user_agent ~ "Go!Zilla") { set $block_user_agents 1; }
			if ($http_user_agent ~ "Download Demon") { set $block_user_agents 1; }
			if ($http_user_agent ~ "Go-Ahead-Got-It") { set $block_user_agents 1; }
			if ($http_user_agent ~ "TurnitinBot") { set $block_user_agents 1; }
			if ($http_user_agent ~ "GrabNet") { set $block_user_agents 1; }
			if ($block_user_agents = 1) { return 404; }
		  
			# Commenting out for `update` for `initiateBatch - apiType` parameter	
			#if ($query_string ~* "(union|select|insert|update|delete|drop|truncate|information_schema|;|--)") {
			#  return 404;
			#}
		  
			if ($query_string ~* "(union|select|insert|delete|drop|truncate|information_schema|;|--)") {
			  return 404;
			}
		  
			#Detect SQL Comment Sequences
			if ($query_string ~* "(/\*!?|\*/|[';]--|--[\s\r\n\v\f]|(?:--[^-]*?-)|([^\-&])#.*?[\s\r\n\v\f]|;?\\x00)"){
			  return 404;
			}
			# String Termination/Statement Ending Injection prevention
			if ($query_string ~* "(^[\"'`Â´â€™â€˜;]+|[\"'`Â´â€™â€˜;]+$)"){
			  return 404;
			}
			#SQL Hex Evasion Methods
			if ($query_string ~* "(?i:(?:\A|[^\d])0x[a-f\d]{3,}[a-f\d]*)"){
			  return 404;
			}
			#SQL Operators
			if ($query_string ~* "(?i:(\!\=|\&\&|\|\||>>|<<|>=|<=|<>|<=>|xor|rlike|regexp|isnull)|(?:not\s+between\s+0\s+and)|(?:is\s+null)|(like\s+null)|(?:(?:^|\W)in[+\s]*\([\s\d\"]+[^()]*\))|(?:xor|<>|rlike(?:\s+binary)?)|(?:regexp\s+binary))"){
			  return 404;
			}
			location ~* \.(htpasswd|git|svn|env|ini|log|conf)$ {
			  return 404;
			}
			
					
			location /partner-origination-processor/actuator/info {
				proxy_pass https://po-backend/partner-origination-processor/actuator/info;
				proxy_set_header Host $host;
				proxy_set_header X-Real-IP $remote_addr;
				proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
				proxy_set_header X-Forwarded-Proto $scheme;
			}

		   location /nimbus-services/api/external-service {
				proxy_pass https://po-backend/partner-origination-processor/api;
				proxy_set_header API-KEY $apikey;
				proxy_set_header GROUP-KEY $groupkey;
				proxy_set_header Host $host;
				proxy_set_header X-Real-IP $remote_addr;
				proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
				proxy_set_header X-Forwarded-Proto $scheme;
			}
		   
			location /nimbus-services/api/po {
				proxy_pass https://po-backend/partner-origination-processor/api/po;
				proxy_set_header API-KEY $apikey;
				proxy_set_header GROUP-KEY $groupkey;
				proxy_set_header Host $host;
				proxy_set_header X-Real-IP $remote_addr;
				proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
				proxy_set_header X-Forwarded-Proto $scheme;
			}
		   
			# Status APIs
		location /nimbus-services/api/po/status {
				proxy_pass https://po-backend-status/partner-origination-processor/api/po/status;
				proxy_set_header API-KEY $apikey;
				proxy_set_header GROUP-KEY $groupkey;
				proxy_set_header Host $host;
				proxy_set_header X-Real-IP $remote_addr;
				proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
				proxy_set_header X-Forwarded-Proto $scheme;
			}
			
			location /nimbus-services/api/po/disbursement/status {
				proxy_pass https://po-backend-status/partner-origination-processor/api/po/disbursement/status;
				proxy_set_header API-KEY $apikey;
				proxy_set_header GROUP-KEY $groupkey;
				proxy_set_header Host $host;
				proxy_set_header X-Real-IP $remote_addr;
				proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
				proxy_set_header X-Forwarded-Proto $scheme;
			}

			location /partner-origination-processor/api/partner-origination/dag/getProgressStatus {
				proxy_pass https://po-backend-status/partner-origination-processor/api/partner-origination/dag/getProgressStatus;
				proxy_set_header API-KEY $apikey;
				proxy_set_header GROUP-KEY $groupkey;
				proxy_set_header Host $host;
				proxy_set_header X-Real-IP $remote_addr;
				proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
				proxy_set_header X-Forwarded-Proto $scheme;
			}

			# Document APIs
			location /nimbus-services/api/po/uploadFile {
				proxy_pass https://po-backend/partner-origination-processor/api/po/uploadFile;
				proxy_set_header API-KEY $apikey;
				proxy_set_header GROUP-KEY $groupkey;
				proxy_set_header Host $host;
				proxy_set_header X-Real-IP $remote_addr;
				proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
				proxy_set_header X-Forwarded-Proto $scheme;
			}
	 
			location /nimbus-services/api/po/coApplicant/uploadFile {
				proxy_pass https://po-backend/partner-origination-processor/api/po/coApplicant/uploadFile;
				proxy_set_header API-KEY $apikey;
				proxy_set_header GROUP-KEY $groupkey;
				proxy_set_header Host $host;
				proxy_set_header X-Real-IP $remote_addr;
				proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
				proxy_set_header X-Forwarded-Proto $scheme;
			}
	 
			location /nimbus-services/api/po/uploadDocument {
				proxy_pass https://po-backend/partner-origination-processor/api/po/uploadDocument;
				proxy_set_header API-KEY $apikey;
				proxy_set_header GROUP-KEY $groupkey;
				proxy_set_header Host $host;
				proxy_set_header X-Real-IP $remote_addr;
				proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
				proxy_set_header X-Forwarded-Proto $scheme;
			}
			
		   location /partner-origination-processor/api/partner-origination/internal {
				proxy_pass https://po-backend;
				proxy_set_header API-KEY $apikey;
				proxy_set_header GROUP-KEY $groupkey;
				proxy_set_header Host $host;
				proxy_set_header X-Real-IP $remote_addr;
				proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
				proxy_set_header X-Forwarded-Proto $scheme;
			}

		   location /partner-origination-processor/api/partner-origination/airflow {
				proxy_pass https://po-backend-disbursement/partner-origination-processor/api/partner-origination/airflow;
				proxy_set_header API-KEY $apikey;
				proxy_set_header GROUP-KEY $groupkey;
				proxy_set_header Host $host;
				proxy_set_header X-Real-IP $remote_addr;
				proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
				proxy_set_header X-Forwarded-Proto $scheme;
			}
			
		}
	}
    ```
	</details>
### Boot up
1. `docker ps -a`
1. `docker compose down` (stop)
1. `docker compose up -d nginx` (start)
1. `docker compose restart nginx` (restart)
1. `docker logs -f <nginx-container-name>` (logs)

### Test & Validate
1. Bring up the following URL in browser `https://10.91.20.59`
1. `tail -f /nimbus/apps/logs/nginx/access.log`
1. `tail -f /nimbus/apps/logs/nginx/error.log`
