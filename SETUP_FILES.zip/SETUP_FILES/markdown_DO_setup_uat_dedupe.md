### UAT Dedupe Server setup
A step-by-step guide for installing Dedupe Application. 

### Prerequisites
1. Admin privileges and SSH access to the server
1. Server should have internet access to be able to download and install packages
1. x86_64 or ARM64 Linux VM with minimum 4 GB RAM and 10GB disk space


### TODO
1. Setup RHEL and Docker (from markdown_DO_setup_uat_rhel_docker.md file) on this VM.
1. Setup Postgres and Restore the DB data
1. Setup NGINX and Dedupe Application.


### Postgres Setup
1. `rm -rf /etc/dnf/vars/releasever` 
1. `dnf --disablerepo='*' remove 'rhui-azure-rhel9-eus'` (remove EUS repo)
1. `dnf --config='https://rhelimage.blob.core.windows.net/repositories/rhui-microsoft-azure-rhel9.config' install rhui-azure-rhel9` (add non EUS repo)
1. `yum clean all`
1. `dnf install https://download.postgresql.org/pub/repos/yum/reporpms/EL-9-x86_64/pgdg-redhat-repo-latest.noarch.rpm -y`(download & install PostgreSQL)
1. `dnf -qy module disable postgresql` (avoid conflicts with default PostgreSQL modules)
1. `dnf install -y postgresql16-server` (install DB)

### Configure DB
1. `mkdir -p /data/do_dedupe_db/pgsql/16/data/`
1. `chown postgres:postgres /data/do_dedupe_db/pgsql/16/data/`
1. `chmod 700 /data/do_dedupe_db/pgsql/16/data/`
1. `su - postgres -c "/usr/pgsql-16/bin/initdb -D /data/do_dedupe_db/pgsql/16/data/"` (run init script as postgres user)
1. `systemctl enable postgresql-16` (enable postgres service)
1. In file "/etc/systemd/system/multi-user.target.wants/postgresql-16.service" replace "/var/lib/pgsql/16/data/" against "Environment=PGDATA=" (~ line 29) variable to "/data/do_dedupe_db/pgsql/16/data/"
1. `systemctl daemon-reload` (reload changes)
1. Update `/data/do_dedupe_db/pgsql/16/data/postgresql.conf`
   1. port 5643 (default is 5432)
   1. listen_addresses = '*'
   1. max_connections = 500
   1. timezone = 'Asia/Kolkata';
   1. log_timezone = 'Asia/Kolkata';
1. Update `/data/do_dedupe_db/pgsql/16/data/pg_hba.conf` file
   1. Add the following two lines towards the end of the file (where other connection config is placed)
       1. `host    all             all             10.91.20.66/32          md5`
	   1. `host    all             all             10.60.35.0/24           scram-sha-256`
	   1. `host    all             all             172.20.0.0/16           md5`
1. `systemctl status postgresql-16` (check status and start)
1. `systemctl start postgresql-16` (check status and start)
1. `dnf install postgresql16-contrib -y` (install crypto package)
1. `ls /usr/pgsql-16/share/extension/pgcrypto.control` (verify it is installed)
1. `systemctl restart postgresql-16` (restart postgres)
1. `sudo -u postgres psql -p 5643` (login to postgres)
1. `CREATE EXTENSION pgcrypto;` (create crypto extension)
1. `SELECT gen_random_uuid();` (verify installation)
1. `SELECT * FROM pg_extension WHERE extname = 'pgcrypto';` (verify crypto's installation)
1. `\q` (exit postgres)

### Validate DB (from linux terminal not from within postgres)
1. `su - postgres -c "psql -p 5643 -c 'SHOW data_directory;'"` (should return 1 record)

## Create DB in Current VM
1. `sudo -u postgres psql -p 5643` (login to postgres)
1. `CREATE database partner_origination_dedupe;` (create the db)
1. `\q`(exit postgres)

## Attach password to postgres user and create app user
1. `sudo -u postgres psql -p 5643` (login to postgres)
1. `ALTER USER postgres WITH PASSWORD 'N!mbu$Dev2oz1'`;
1. `CREATE USER nimbus_app_user WITH PASSWORD 'N!mbu$Dev2oz5';`
1. `GRANT CONNECT ON DATABASE partner_origination_dedupe TO nimbus_app_user;`
1. Validate this user/password by logging in

## Create the required Schemas and Tables
1. Login to Postgres user using `sudo -u postgres psql -p 5643` and Run the below DB scripts one by one to ensure all the required schemas, tables and data is present before turning up Dedupe Application
	```
	\c partner_origination_dedupe; (To switch to dedupe DB)
	CREATE SCHEMA config AUTHORIZATION postgres;
	CREATE SCHEMA po AUTHORIZATION postgres;
	
	CREATE TABLE config.property_mapper (
		"key" varchar(255) NOT NULL,
		value varchar NULL,
		created_by int8 NULL,
		created_date timestamp NULL,
		last_modified_by int8 NULL,
		last_modified_date timestamp NULL,
		property_name varchar NOT NULL,
		CONSTRAINT property_mapper_pk PRIMARY KEY (key, property_name)
	);
	
	CREATE TABLE po.dedupe_customer_personal_info (
		credit_hub_id int8 NOT NULL,
		created_by int8 NULL,
		created_date timestamp NULL,
		last_modified_by int8 NULL,
		last_modified_date timestamp NULL,
		client_id varchar(255) NULL,
		company_pan varchar(255) NULL,
		email varchar(255) NULL,
		gst_number varchar(255) NULL,
		loan_id varchar(255) NULL,
		mobile varchar(255) NULL,
		originator_id varchar(255) NULL,
		pan varchar(255) NULL,
		sanction_application_id varchar(255) NULL,
		udyam_number varchar(255) NULL,
		id varchar NOT NULL,
		CONSTRAINT dedupe_customer_personal_info_pkey PRIMARY KEY (id),
		CONSTRAINT dedupe_unique_customer_info_credit_hub_id UNIQUE (credit_hub_id)
	);
	CREATE SEQUENCE po.dedupe_customer_personal_info_id_seq START WITH 1 INCREMENT BY 1;
	ALTER TABLE po.dedupe_customer_personal_info ALTER COLUMN id SET DEFAULT nextval('po.dedupe_customer_personal_info_id_seq'::regclass);
	CREATE INDEX dedupe_customer_personal_info_originator_id_idx ON po.dedupe_customer_personal_info USING btree (originator_id);
	
	CREATE TABLE po.in_house_lms (
		reference_id int8 NOT NULL,
		credit_hub_id int8 NOT NULL,
		client_id varchar NOT NULL,
		sanction_reference_id int8 NOT NULL,
		loan_id varchar NULL,
		originator_id varchar NOT NULL,
		sector_id int4 NOT NULL,
		applicant_type int4 NOT NULL,
		is_active bool NOT NULL,
		created_by int8 NULL,
		created_date timestamp NULL,
		last_modified_by int8 NULL,
		last_modified_date timestamp NULL,
		payload text NOT NULL,
		company_pan varchar(255) NULL,
		mobile varchar(255) NULL,
		pan varchar(255) NULL,
		CONSTRAINT in_house_lms_pk PRIMARY KEY (reference_id)
	);
	
	INSERT INTO config.property_mapper
	("key", value, created_by, created_date, last_modified_by, last_modified_date, property_name)
	VALUES('SECRET_KEY', 'F2388451B0954326', NULL, NULL, NULL, NULL, 'PI_ENCRYPT');
	INSERT INTO config.property_mapper
	("key", value, created_by, created_date, last_modified_by, last_modified_date, property_name)
	VALUES('ALGO', 'compress-algo=1, cipher-algo=aes256', NULL, NULL, NULL, NULL, 'PI_ENCRYPT');
	INSERT INTO config.property_mapper
	("key", value, created_by, created_date, last_modified_by, last_modified_date, property_name)
	VALUES('ENCODE', 'BASE64', NULL, NULL, NULL, NULL, 'PI_ENCRYPT');
	
	```

## NGINX and Dedupe Setup
### Pre-reqs (run under sudo)
1. `mkdir -p /nimbus/apps/api/partner-origination-dedupe /nimbus/apps/certificates/2025 /nimbus/apps/logs/nginx /nimbus/apps/api/partner-origination-dedupe/config`
1. `touch /nimbus/apps/api/partner-origination-dedupe/docker-compose.yml /nimbus/apps/api/partner-origination-dedupe/nginx.conf /nimbus/apps/api/partner-origination-dedupe/config/application.yaml /nimbus/apps/api/partner-origination-dedupe/elasticapm.properties`
1. Copy ***nac2025.crt*** & ***nac2025.key*** from certificates-2025 folder in Sharepoint to /nimbus/apps/certificates/2025 on 10.91.20.66 (current VM)
1. Copy the following script into ***docker-compose.yml***
    ```
	services:
     
      partner-dedupe-app:
        image: nexus.northernarc.com/npos/release/api/partner-origination-dedupe-api/cr-1.10.52-20:latest
        #image:  nexus.northernarc.com/npos/release/api/partner-origination-dedupe-api/${IMAGE_TAG} Latest Image Tag to be provided.
        environment:
          - TZ=Asia/Kolkata
        ports:
          - "8289"
        volumes:
          - /nimbus:/nimbus
          - /etc/hosts:/etc/hosts
          - /nimbus/apps/logs/partner-origination-dedupe-api:/nimbus/apps/logs/partner-origination-dedupe-api
          - ./config/application.yaml:/nimbus/apps/api/partner-origination-dedupe/config/application.yaml
          - ./elasticapm.properties:/app/elasticapm.properties
        healthcheck:
          test: [ "CMD","curl","http://127.0.0.1:8289/partner-origination-dedupe-processor/actuator/health" ]
          interval: 10s
          timeout: 10s
          retries: 100
        deploy:
          replicas: 4
        networks:
          - dedupe-api-network

      nginx:
        image: nexus.northernarc.com/release/nimbus.po.nginx:1.0.0
        environment:
          - TZ=Asia/Kolkata
        ports:
          - "443:443"
          - "80:80"
        volumes:
          - /nimbus/apps/logs/nginx:/var/log/nginx
          - ./nginx.conf:/etc/nginx/nginx.conf:ro
          - /nimbus/apps/certificates:/nimbus/apps/certificates:ro
        networks:
          - dedupe-api-network

    networks:
      dedupe-api-network:
        driver: bridge
        ipam:
          config:
            - subnet: "172.20.0.0/16"
   ```
1. Copy the following script into ***nginx.conf***
    ```
    user nginx;
    worker_processes auto;  # Automatically adjust based on available CPU cores
    pid /run/nginx.pid;
    worker_rlimit_nofile 100000;  # Set the maximum number of open files

    # Include dynamic modules
    include /usr/share/nginx/modules/*.conf;

    events {
        worker_connections 10240;  # Set worker connections; 10,240 is often sufficient and safer
        multi_accept on;  # Accept multiple connections at once
        use epoll;  # Use epoll for better performance on Linux
    }

    http {

    # Basic Settings
        sendfile on;
        tcp_nopush on;
        tcp_nodelay on;
        types_hash_max_size 2048;
        
        include /etc/nginx/mime.types;
        default_type application/octet-stream;

        log_format json_combined escape=json '{'
        '"time_local":"$time_local",'
          '"remote_user":"$remote_user",'
        '"remote_addr":"$remote_addr",'
        '"remote_port":"$remote_port",'
        '"request":"$request",'
        '"status":"$status",'
        '"body_bytes_sent":"$body_bytes_sent",'
        '"http_referer":"$http_referer",'
        '"http_user_agent":"$http_user_agent",'
        '"http_x_forwarded_for":"$http_x_forwarded_for",'
        '"request_time":"$request_time",'
        '"upstream_response_time":"$upstream_response_time",'
        '"upstream_connect_time":"$upstream_connect_time",'
        '"upstream_header_time":"$upstream_header_time",'
        '"upstream_addr":"$upstream_addr",'
        '"server_name":"$server_name",'
        '"connection":"$connection",'
        '"connection_requests":"$connection_requests",'
        '"bytes_received":"$request_length",'
        '"client_protocol":"$server_protocol",'
        '"host":"$host",'
        '"uri":"$uri",'
        '"args":"$args",'
        '"nginx_version":"$nginx_version"'
        '}';

        access_log /var/log/nginx/access.log json_combined;
        error_log /var/log/nginx/error.log crit;  # Log critical errors only

        # Gzip Settings
        gzip on;
        gzip_disable "msie6";
        gzip_vary on;
        gzip_proxied any;
        gzip_comp_level 6;  # Balance between compression level and performance
        gzip_buffers 16 8k;
        gzip_http_version 1.1;
        gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;

        # File Cache Settings
        open_file_cache max=200000 inactive=20s;
        open_file_cache_valid 30s;
        open_file_cache_min_uses 2;
        open_file_cache_errors on;

        # Timeouts and Limits
        client_body_timeout 10s;
        send_timeout 2s;
        reset_timedout_connection on;
        client_max_body_size 50M;  # Set a reasonable limit to prevent abuse
        proxy_connect_timeout 180s;
        proxy_read_timeout 180s; # Lowered from 600s for better performance
        proxy_send_timeout 180s;
        keepalive_timeout 180s;  # Increased to 180s to accomodate UM TAT
        keepalive_requests 1000; # Max no.of requests a single connection can serve
        
        upstream backend-po-dedupe {
            least_conn;
            server partner-dedupe-app:8289;
        }

        map $http_group_key $groupkey {
            default   $http_group_key;
            ""        "SERV_00000000001";
        }

        map $http_api_key $apikey {
            default   $http_api_key;
            ""        $http_x_api_key;
        }

        # HTTPS Server Block
        server {
            listen 443 ssl http2 default_server;
            server_name 10.91.20.66;

            # SSL Configuration
            ssl_certificate /nimbus/apps/certificates/2025/nac2025.crt;
            ssl_certificate_key /nimbus/apps/certificates/2025/nac2025.key;

            ssl_session_cache shared:SSL:10m;
            ssl_session_timeout 10m;
            ssl_prefer_server_ciphers on;
            ssl_protocols TLSv1.2;
            ssl_ciphers 'ECDHE-RSA-AES128-GCM-SHA256:AES128+EECDH:AES128+EDH';

            include /etc/nginx/default.d/*.conf;

            error_page 404 /404.html;
            error_page 500 502 503 504 /50x.html;

            location = /40x.html {}
            location = /50x.html {}

          include /etc/nginx/conf.d/allowed_ip.conf;
        add_header Set-Cookie "Path=/; HttpOnly; Secure";
        add_header X-XSS-Protection "1; mode=block";
        add_header X-Content-Type-Options "nosniff";
        add_header X-Frame-Options "DENY";
        add_header Content-Security-Policy "default-src 'self';";
        location ~* "(eval())"  { return 404; }
        location ~* "([a-z0-9]{2000})" { return 404; }
        location ~* "(javascript:)(.*)(;)"  { return 404; }
        location ~* "(base64_encode)(.*)(())"  { return 404; }
        location ~* "(GLOBALS|REQUEST)(=|[|]%)"  { return 404; }
        location ~* "(<|%3C).*script.*(>|%3)" { return 404; }
        location ~* "(boot.ini|etc/passwd|self/environ)" { return 404; }
        location ~* "(thumbs?(_editor|open)?|tim(thumb)?).php" { return 404; }
        location ~* "(')(.*)(drop|insert|md5|select|union)" { return 404; }
        location ~* "(https?|ftp|php):/" { return 404; }
        location ~* "(='|=%27|/'/?)." { return 404; }
        #location ~* "/(=|$&|_mm|(wp-)?config.|cgi-|etc/passwd|muieblack)" { return 404; }
        location ~* "/(=|$&|_mm|(wp-)?cgi-|etc/passwd|muieblack)" { return 404; }
        location ~* "(&pws=0|_vti_|(null)|{$itemURL}|echo(.*)kae|etc/passwd|eval(|self/environ))" { return 404; }
        location ~* "\.(aspx?|bash|bak?|cfg|cgi|dll|exe|git|hg|ini|jsp|mdb|sql|svn|swp|tar|rdf)$" { return 404; }
        #location ~* ".(aspx?|bash|bak?|cfg|cgi|dll|exe|git|hg|ini|jsp|log|mdb|out|sql|svn|swp|tar|rdf)$" { return 404; }
        location ~* "/(^$|mobiquo|phpinfo|shell|sqlpatch|thumb|thumb_editor|thumbopen|timthumb|webshell).php" { return 404; }

        set $block_sql_injections 0; 
        if ($query_string ~ "(union.*select.*)") { set $block_sql_injections 1; }
        if ($query_string ~ "union.*all.*select.*") { set $block_sql_injections 1; }
        if ($query_string ~ "concat.*") { set $block_sql_injections 1; }
        if ($block_sql_injections = 1) { return 404; }
        #
        set $block_file_injections 0;
        if ($query_string ~ "[a-zA-Z0-9_]=http://") { set $block_file_injections 1; }
        if ($query_string ~ "[a-zA-Z0-9_]=(\.\./)+") { set $block_file_injections 1; }
        if ($query_string ~ "[a-zA-Z0-9_]=/([a-z0-9_.]//?)+") { set $block_file_injections 1; }
        if ($block_file_injections = 1) { return 404; }
        #
        set $block_common_exploits 0;
        if ($query_string ~ "(<|%3C).*script.*(>|%3E)") { set $block_common_exploits 1; }
        if ($query_string ~ "GLOBALS(=|[|%[0-9A-Z]{0,2})") { set $block_common_exploits 1; }
        if ($query_string ~ "_REQUEST(=|[|%[0-9A-Z]{0,2})") { set $block_common_exploits 1; }
        if ($query_string ~ "proc/self/environ") { set $block_common_exploits 1; }
        if ($query_string ~ "mosConfig_[a-zA-Z_]{1,21}(=|%3D)") { set $block_common_exploits 1; }
        if ($query_string ~ "base64_(en|de)code(.*)") { set $block_common_exploits 1; }
        if ($block_common_exploits = 1) { return 404; }
        #
        set $block_spam 0;
        if ($query_string ~ "b(ultram|unicauca|valium|viagra|vicodin|xanax|ypxaieo)b") { set $block_spam 1; }
        if ($query_string ~ "b(erections|hoodia|huronriveracres|impotence|levitra|libido)b") { set $block_spam 1; }
        if ($query_string ~ "b(ambien|bluespill|cialis|cocaine|ejaculation|erectile)b") { set $block_spam 1; }
        if ($query_string ~ "b(lipitor|phentermin|pro[sz]ac|sandyauer|tramadol|troyhamby)b") { set $block_spam 1; }
        if ($block_spam = 1) { return 404; }
        #
        set $block_user_agents 0;
        if ($http_user_agent ~ "Indy Library") { set $block_user_agents 1; }
        if ($http_user_agent ~ "libwww-perl") { set $block_user_agents 1; }
        if ($http_user_agent ~ "GetRight") { set $block_user_agents 1; }
        if ($http_user_agent ~ "GetWeb!") { set $block_user_agents 1; }
        if ($http_user_agent ~ "Go!Zilla") { set $block_user_agents 1; }
        if ($http_user_agent ~ "Download Demon") { set $block_user_agents 1; }
        if ($http_user_agent ~ "Go-Ahead-Got-It") { set $block_user_agents 1; }
        if ($http_user_agent ~ "TurnitinBot") { set $block_user_agents 1; }
        if ($http_user_agent ~ "GrabNet") { set $block_user_agents 1; }
        if ($block_user_agents = 1) { return 404; }
      
        # Commenting out for `update` for `initiateBatch - apiType` parameter    
        #if ($query_string ~* "(union|select|insert|update|delete|drop|truncate|information_schema|;|--)") {
        #  return 404;
        #}

        if ($query_string ~* "(union|select|insert|delete|drop|truncate|information_schema|;|--)") {
          return 404;
        }

        #Detect SQL Comment Sequences
        if ($query_string ~* "(/\*!?|\*/|[';]--|--[\s\r\n\v\f]|(?:--[^-]*?-)|([^\-&])#.*?[\s\r\n\v\f]|;?\\x00)"){
          return 404;
        }
        # String Termination/Statement Ending Injection prevention
        if ($query_string ~* "(^[\"'`´’‘;]+|[\"'`´’‘;]+$)"){
          return 404;
        }
        #SQL Hex Evasion Methods
        if ($query_string ~* "(?i:(?:\A|[^\d])0x[a-f\d]{3,}[a-f\d]*)"){
          return 404;
        }
        #SQL Operators
        if ($query_string ~* "(?i:(\!\=|\&\&|\|\||>>|<<|>=|<=|<>|<=>|xor|rlike|regexp|isnull)|(?:not\s+between\s+0\s+and)|(?:is\s+null)|(like\s+null)|(?:(?:^|\W)in[+\s]*\([\s\d\"]+[^()]*\))|(?:xor|<>|rlike(?:\s+binary)?)|(?:regexp\s+binary))"){
          return 404;
        }
        location ~* \.(htpasswd|git|svn|env|ini|log|conf)$ {
          return 404;
        }

            location /nginx_status {
                stub_status;
                allow 127.0.0.1;
            allow 10.91.20.66;
            proxy_pass https://10.91.20.66:443/;            
           # allow all;            # Only allow requests from localhost
                deny all;          # Deny all other requests
            }
            
            location /partner-origination-dedupe-processor {
                    proxy_pass  http://backend-po-dedupe;
                    proxy_set_header API-KEY $apikey;
                    proxy_set_header GROUP-KEY $groupkey;
            }
            

        }
        
         # HTTP Server Block
        server {
            listen 80 default_server;
            listen [::]:80 default_server;
            server_name 10.91.20.66;
            root /usr/share/nginx/html;

            include /etc/nginx/default.d/*.conf;

            error_page 404 /404.html;
            error_page 500 502 503 504 /50x.html;

            location = /40x.html {}
            location = /50x.html {}

            location /nginx_status {
                    stub_status;
                    allow 127.0.0.1;  # Only allow requests from localhost
                    deny all;          # Deny all other requests
            }
            
               
            location /partner-origination-dedupe-processor {
                    proxy_pass  http://backend-po-dedupe;
                    proxy_set_header API-KEY $apikey;
                    proxy_set_header GROUP-KEY $groupkey;
            }
            
        }

        
    }
    ```
	
1. Copy the following script into /nimbus/apps/api/partner-origination-dedupe/config/application.yaml
   ```
   jasypt:
      encryptor:
        password: Nimbus
    nimbus:
      app:
        id: DEDUPE 
        eo:
          base:
            api:
              url: 'https://ENTITY-ONBOARDING/eo/api/'
            url: 'https://ENTITY-ONBOARDING/eo/api/entity'
          stage:
            info: '/entity/stage/{entityId}/{sectorId}'
        um:
          base:
            url: 'https://DOSTAGE-UM/um/api'
          team:
            info: /team
          userinfo:
            by:
              role:
                url: '/user/role/{roleId}/{appId}'
              team:
                url: '/user/team/{teamId}/'
              userId:
                url: '/user/id/{userId}'
            email: '/user/userinfo/email/{email}'
            token:
              url: '/user/token/app/{appId}'
            url: /user/userinfo 
    server:
      compression:
        enabled: true
        mime-types: application/json
      port: 8289
      servlet:
        context-path: /partner-origination-dedupe-processor
      tomcat:
        keep-alive-timeout: -1
        maxKeepAliveRequests: 10000
        threads.max: 500
        max-connections: 50000
        accept-count: 5000
    eureka:
      client:
        registerWithEureka: true
        fetchRegistry: true
        serviceUrl:
          defaultZone: 'http://10.91.20.65:8761/eureka/eureka/'
      instance:
        preferIpAddress: true
        secure-port: 443
        secure-port-enabled: true
    spring:
      main:
        allow-bean-definition-overriding: true
      application:
        name: DOSTAGE-DEDUPE-PROCESSOR
      datasource:
        driver-class-name: org.postgresql.Driver
        initialize: true
        url: 'jdbc:postgresql://10.91.20.66:5643/partner_origination_dedupe?ApplicationName=DEDUPE-APP'
        username: nimbus_app_user
        password: N!mbu$Dev2oz5
        hikari:
          idleTimeout: 6000
          maxLifetime: 60000
          maximumPoolSize: 100
          minimumIdle: 1
          connectionTimeout: 60000
      jpa:
        database-platform: org.hibernate.dialect.PostgreSQL9Dialect
        properties:
          hibernate:
            enable_lazy_load_no_trans: true
            temp:
              use_jdbc_metadata_defaults: false
        show-sql: false
    swagger:
        username: Admin
        password: Nimbus2k24
    management:
      endpoints:
        web:
          exposure:
            include: '*'
      security:
        enabled: false
      endpoint:
        health:
          show-details: always
      metrics:
        tags:
          application: NPOS-DEDUPE-API
    checkstyle.enable: false
   ```

1. Copy the following script into /nimbus/apps/api/partner-origination-dedupe/elasticapm.properties
    ```
    service_name=PO-STAGE
    server_urls=http://10.91.20.65:8200
    profiling_inferred_spans_enabled=true
    log_level=INFO
    environment=STAGE
    secret_token=Nimbus@2K24
    ```
	
### Boot up
1. `docker ps -a`
1. `docker compose down` (stop)
1. `docker compose up -d` (start)
1. `docker compose restart` (restart)
1. `docker logs -f <container-name>` (logs)

### Test & Validate
1. Bring up the following URL in browser `https://10.91.20.66/partner-origination-dedupe-processor/swagger-ui/index.html`
1. Check the container status using `docker compose ps -a`
1. Check the container logs using `docker compose logs -f`
