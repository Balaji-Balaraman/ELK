## Server: 10.91.20.62
1. Login into the server 10.91.20.62

1. Authenticate and switch to root
    1. `sudo su` (become sudo)


## Metricbeat
1. Install metricbeat
    1. `curl -L -O https://artifacts.elastic.co/downloads/beats/metricbeat/metricbeat-7.17.24-x86_64.rpm`
    1. `sudo rpm -ivh metricbeat-7.17.24-x86_64.rpm`


2. Configure metricbeat
   1. `mv /etc/metricbeat/metricbeat.yml /etc/metricbeat/metricbeat.yml_bkp` (take backup)
   1. `sudo vi /etc/metricbeat/metricbeat.yml` 
   1. Copy and past it with the following content.
<details>
    <summary>Click to expand</summary>

``` 
###################### Metricbeat Configuration Example #######################

# This file is an example configuration file highlighting only the most common
# options. The metricbeat.reference.yml file from the same directory contains all the
# supported options with more comments. You can use it as a reference.
#
# You can find the full configuration reference here:
# https://www.elastic.co/guide/en/beats/metricbeat/index.html

# =========================== Modules configuration ============================

metricbeat.config.modules:
  # Glob pattern for configuration loading
  path: ${path.config}/modules.d/*.yml

  # Set to true to enable config reloading
  reload.enabled: true

  # Period on which files under path should be checked for changes
  #reload.period: 10s

# ======================= Elasticsearch template setting =======================

setup.template.settings:
  index.number_of_shards: 1
  index.codec: best_compression
  #_source.enabled: false


# ================================== General ===================================

# The name of the shipper that publishes the network data. It can be used to group
# all the transactions sent by a single shipper in the web interface.
#name:

# The tags of the shipper are included in their own field with each
# transaction published.
#tags: ["service-X", "web-tier"]

# Optional fields that you can specify to add additional information to the
# output.
#fields:
#  env: staging

# ================================= Dashboards =================================
# These settings control loading the sample dashboards to the Kibana index. Loading
# the dashboards is disabled by default and can be enabled either by setting the
# options here or by using the `setup` command.
setup.dashboards.enabled: true

# The URL from where to download the dashboards archive. By default this URL
# has a value which is computed based on the Beat name and version. For released
# versions, this URL points to the dashboard archive on the artifacts.elastic.co
# website.
#setup.dashboards.url:

# =================================== Kibana ===================================

# Starting with Beats version 6.0.0, the dashboards are loaded via the Kibana API.
# This requires a Kibana endpoint configuration.
setup.kibana:
  host: "10.91.20.65:5601"
  username: "elastic"
  password: "Nimbus@2K24"
  # Kibana Host
  # Scheme and port can be left out and will be set to the default (http and 5601)
  # In case you specify and additional path, the scheme is required: http://localhost:5601/path
  # IPv6 addresses should always be defined as: https://[2001:db8::1]:5601
  #host: "localhost:5601"

  # Kibana Space ID
  # ID of the Kibana Space into which the dashboards should be loaded. By default,
  # the Default Space will be used.
  #space.id:

# =============================== Elastic Cloud ================================

# These settings simplify using Metricbeat with the Elastic Cloud (https://cloud.elastic.co/).

# The cloud.id setting overwrites the `output.elasticsearch.hosts` and
# `setup.kibana.host` options.
# You can find the `cloud.id` in the Elastic Cloud web UI.
#cloud.id:

# The cloud.auth setting overwrites the `output.elasticsearch.username` and
# `output.elasticsearch.password` settings. The format is `<user>:<pass>`.
#cloud.auth:

# ================================== Outputs ===================================

# Configure what output to use when sending the data collected by the beat.

# ---------------------------- Elasticsearch Output ----------------------------
output.elasticsearch:
  # Array of hosts to connect to.
  hosts: ["10.91.20.65:9200"]

  # Protocol - either `http` (default) or `https`.
  protocol: "https"

  # Authentication credentials - either API key or username/password.
  #api_key: "id:api_key"
  username: "elastic"
  password: "Nimbus@2K24"
  ssl:
    verification_mode: "none"
# ------------------------------ Logstash Output -------------------------------
#output.logstash:
  # The Logstash hosts
  #hosts: ["localhost:5044"]

  # Optional SSL. By default is off.
  # List of root certificates for HTTPS server verifications
  #ssl.certificate_authorities: ["/etc/pki/root/ca.pem"]

  # Certificate for SSL client authentication
  #ssl.certificate: "/etc/pki/client/cert.pem"

  # Client Certificate Key
  #ssl.key: "/etc/pki/client/cert.key"

# ================================= Processors =================================

# Configure processors to enhance or manipulate events generated by the beat.

processors:
  - add_host_metadata: ~
    #- add_cloud_metadata: ~
  - add_docker_metadata: ~
    # - add_kubernetes_metadata: ~


# ================================== Logging ===================================

# Sets log level. The default log level is info.
# Available log levels are: error, warning, info, debug
#logging.level: debug

# At debug level, you can selectively enable logging only for some components.
# To enable all selectors use ["*"]. Examples of other selectors are "beat",
# "publisher", "service".
#logging.selectors: ["*"]

# ============================= X-Pack Monitoring ==============================
# Metricbeat can export internal metrics to a central Elasticsearch monitoring
# cluster.  This requires xpack monitoring to be enabled in Elasticsearch.  The
# reporting is disabled by default.

# Set to true to enable the monitoring reporter.
#monitoring.enabled: false

# Sets the UUID of the Elasticsearch cluster under which monitoring data for this
# Metricbeat instance will appear in the Stack Monitoring UI. If output.elasticsearch
# is enabled, the UUID is derived from the Elasticsearch cluster referenced by output.elasticsearch.
#monitoring.cluster_uuid:

# Uncomment to send the metrics to Elasticsearch. Most settings from the
# Elasticsearch output are accepted here as well.
# Note that the settings should point to your Elasticsearch *monitoring* cluster.
# Any setting that is not set is automatically inherited from the Elasticsearch
# output configuration, so if you have the Elasticsearch output configured such
# that it is pointing to your Elasticsearch monitoring cluster, you can simply
# uncomment the following line.
#monitoring.elasticsearch:

# ============================== Instrumentation ===============================

# Instrumentation support for the metricbeat.
instrumentation:
    # Set to true to enable instrumentation of metricbeat.
    enabled: true

    # Environment in which metricbeat is running on (eg: staging, production, etc.)
    environment: "stage"

    # APM Server hosts to report instrumentation results to.
    hosts:
      - http://10.91.20.65:8200

    # API Key for the APM Server(s).
    # If api_key is set then secret_token will be ignored.
    #api_key:

    # Secret token for the APM Server(s).
    secret_token: Nimbus@2K24


# ================================= Migration ==================================

# This allows to enable 6.7 migration aliases
#migration.6_to_7.enabled: true       
```
</details>

3. Navigate to the metricbeat modules directory
    1. `cd /etc/metricbeat/modules.d`

4. Edit Docker file
    1. `sudo vi docker.yml`
    1.  Copy and paste it with the following content.
<details>
    <summary>Click to expand</summary>

```
# Module: docker
# Docs: https://www.elastic.co/guide/en/beats/metricbeat/7.17/metricbeat-module-docker.html

- module: docker
  metricsets:
    - container
    - cpu
    - diskio
    - event
    - healthcheck
    - info
    - memory
    - network
    - network_summary
  period: 10s
  hosts: ["unix:///var/run/docker.sock"]

  # If set to true, replace dots in labels with `_`.
  #labels.dedot: false

  # To connect to Docker over TLS you must specify a client and CA certificate.
  #ssl:
    #certificate_authority: "/etc/pki/root/ca.pem"
    #certificate:           "/etc/pki/client/cert.pem"
    #key:                   "/etc/pki/client/cert.key"        
```
</details>       

5. Verify enabled modules `metricbeat modules list`

6. Enable metricbeat system module `sudo metricbeat modules enable system`

7. Set up metricbeat dashboards `sudo metricbeat setup --dashboards`

8. Start metricbeat service `sudo systemctl start metricbeat`

9. Check metricbeat status `sudo systemctl status metricbeat`


## Heartbeat
1. Install heartbeat
   1. `curl -L -O https://artifacts.elastic.co/downloads/beats/heartbeat/heartbeat-7.17.24-x86_64.rpm`
   1. `sudo rpm -ivh heartbeat-7.17.24-x86_64.rpm`

1. Edit the heartbeat.yml
   1. `mv /etc/heartbeat/heartbeat.yml /etc/heartbeat/heartbeat.yml_bkp` (take backup)
   1. `sudo vi /etc/heartbeat/heartbeat.yml`
   1. Copy and paste it with the following content.
<details>
    <summary>Click to expand</summary>

```
################### Heartbeat Configuration Example #########################

# This file is an example configuration file highlighting only some common options.
# The heartbeat.reference.yml file in the same directory contains all the supported options
# with detailed comments. You can use it for reference.
#
# You can find the full configuration reference here:
# https://www.elastic.co/guide/en/beats/heartbeat/index.html

############################# Heartbeat ######################################

# Define a directory to load monitor definitions from. Definitions take the form
# of individual yaml files.
heartbeat.config.monitors:
  # Directory + glob pattern to search for configuration files
  path: ${path.config}/monitors.d/*.yml
  # If enabled, heartbeat will periodically check the config.monitors path for changes
  reload.enabled: false
  # How often to check for changes
  reload.period: 5s

# Configure monitors inline
#heartbeat.monitors:
#- type: http
  # Set enabled to true (or delete the following line) to enable this example monitor
  #enabled: true
  # ID used to uniquely identify this monitor in elasticsearch even if the config changes
  #id: my-monitor
  # Human readable display name for this service in Uptime UI and elsewhere
  #name: My Monitor
  # List or urls to query
  #urls: ["https://localhost:9200"]
  # Configure task schedule
  #schedule: '@every 10s'
  #ssl.verification_mode: none
  #username: "elastic"    # Replace with the correct username
  #password: "NimbusQA@2K24"    # Replace with the correct password
  # Total test connection and data exchange timeout
  #timeout: 16s
  # Name of corresponding APM service, if Elastic APM is in use for the monitored service.
  #service.name: my-apm-service-name

# Experimental: Set this to true to run heartbeat monitors exactly once at startup
#heartbeat.run_once: true

# ======================= Elasticsearch template setting =======================

setup.template.settings:
  index.number_of_shards: 1
  index.codec: best_compression
  #_source.enabled: false

# ================================== General ===================================

# The name of the shipper that publishes the network data. It can be used to group
# all the transactions sent by a single shipper in the web interface.
#name:

# The tags of the shipper are included in their own field with each
# transaction published.
#tags: ["service-X", "web-tier"]

    #tags: ["heartbeat", "production", "ELK Server"]

# Optional fields that you can specify to add additional information to the
# output.
fields:
  env: stage


# =================================== Kibana ===================================

# Starting with Beats version 6.0.0, the dashboards are loaded via the Kibana API.
# This requires a Kibana endpoint configuration.
setup.kibana:

  # Kibana Host
  # Scheme and port can be left out and will be set to the default (http and 5601)
  # In case you specify and additional path, the scheme is required: http://localhost:5601/path
  # IPv6 addresses should always be defined as: https://[2001:db8::1]:5601
  #host: "localhost:5601"
  host: "10.91.20.65:5601"
  username: "elastic"
  password: "Nimbus@2K24"
  # Kibana Space ID
  # ID of the Kibana Space into which the dashboards should be loaded. By default,
  # the Default Space will be used.
  #space.id:

# =============================== Elastic Cloud ================================

# These settings simplify using Heartbeat with the Elastic Cloud (https://cloud.elastic.co/).

# The cloud.id setting overwrites the `output.elasticsearch.hosts` and
# `setup.kibana.host` options.
# You can find the `cloud.id` in the Elastic Cloud web UI.
#cloud.id:

# The cloud.auth setting overwrites the `output.elasticsearch.username` and
# `output.elasticsearch.password` settings. The format is `<user>:<pass>`.
#cloud.auth:

# ================================== Outputs ===================================

# Configure what output to use when sending the data collected by the beat.

# ---------------------------- Elasticsearch Output ----------------------------
output.elasticsearch:
  # Array of hosts to connect to.
  hosts: ["10.91.20.65:9200"]

  # Protocol - either `http` (default) or `https`.
  protocol: "https"

  # Authentication credentials - either API key or username/password.
  #api_key: "id:api_key"
  username: "elastic"
  password: "Nimbus@2K24"
  ssl:
    verification_mode: "none"
  #index: "heartbeatqaserver-%{+yyyy.MM.dd}"
  # Specify the custom index name
  #index: "heartbeat_qaserverindex"
# ------------------------------ Logstash Output -------------------------------
#output.logstash:
  # The Logstash hosts
  #hosts: ["localhost:5044"]

  # Optional SSL. By default is off.
  # List of root certificates for HTTPS server verifications
  #ssl.certificate_authorities: ["/etc/pki/root/ca.pem"]

  # Certificate for SSL client authentication
  #ssl.certificate: "/etc/pki/client/cert.pem"

  # Client Certificate Key
  #ssl.key: "/etc/pki/client/cert.key"

# ================================= Processors =================================

processors:
  - add_observer_metadata:
      # Optional, but recommended geo settings for the location Heartbeat is running in
      #geo:
        # Token describing this location
        #name: us-east-1a
        # Lat, Lon "
        #location: "37.926868, -78.024902"

# ================================== Logging ===================================

# Sets log level. The default log level is info.
# Available log levels are: error, warning, info, debug
#logging.level: debug

# At debug level, you can selectively enable logging only for some components.
# To enable all selectors use ["*"]. Examples of other selectors are "beat",
# "publisher", "service".
#logging.selectors: ["*"]

# ============================= X-Pack Monitoring ==============================
# Heartbeat can export internal metrics to a central Elasticsearch monitoring
# cluster.  This requires xpack monitoring to be enabled in Elasticsearch.  The
# reporting is disabled by default.

# Set to true to enable the monitoring reporter.
#monitoring.enabled: false

# Sets the UUID of the Elasticsearch cluster under which monitoring data for this
# Heartbeat instance will appear in the Stack Monitoring UI. If output.elasticsearch
# is enabled, the UUID is derived from the Elasticsearch cluster referenced by output.elasticsearch.
#monitoring.cluster_uuid:

# Uncomment to send the metrics to Elasticsearch. Most settings from the
# Elasticsearch output are accepted here as well.
# Note that the settings should point to your Elasticsearch *monitoring* cluster.
# Any setting that is not set is automatically inherited from the Elasticsearch
# output configuration, so if you have the Elasticsearch output configured such
# that it is pointing to your Elasticsearch monitoring cluster, you can simply
# uncomment the following line.
#monitoring.elasticsearch:

# ============================== Instrumentation ===============================

# Instrumentation support for the heartbeat.
instrumentation:
    # Set to true to enable instrumentation of heartbeat.
    enabled: true

    # Environment in which heartbeat is running on (eg: staging, production, etc.)
    environment: "stage"

    # APM Server hosts to report instrumentation results to.
    hosts:
      - http://10.91.20.65:8200

    # API Key for the APM Server(s).
    # If api_key is set then secret_token will be ignored.
    #api_key:

    # Secret token for the APM Server(s).
    secret_token: Nimbus@2K24


# ================================= Migration ==================================

# This allows to enable 6.7 migration aliases
#migration.6_to_7.enabled: true       
```
</details>

1. Backup the sample.http.yml file 
    1. `sudo mv /etc/heartbeat/monitors.d/sample.http.yml.disabled /etc/heartbeat/monitors.d/sample.http.yml_bkp`

1. Edit the sample.http.yml 
    1. `sudo vi /etc/heartbeat/monitors.d/sample.http.yml`
    1. Update sample.http.yml with the following content.
<details>
    <summary>Click to expand</summary>

``` 
- enabled: true
  hosts: ['https://10.91.20.62:443']
  id: my-http-monitor-1
  ipv4: true
  ipv6: true
  mode: any
  name: partner-origination-nginx-1
  schedule: '@every 5s'
  ssl.verification_mode: none
  type: http
  tags:
    - Status App
    - Stage-server
- enabled: true
  hosts: ['http://10.91.20.62:32776/partner-origination-processor']
  id: my-http-monitor-2
  ipv4: true
  ipv6: true
  mode: any
  name: partner-origination-status-app-1
  schedule: '@every 5s'
  ssl.verification_mode: none
  type: http
  tags:
    - Status App
    - Stage-server
- enabled: false
  hosts: ['http://10.91.20.62:32807/partner-origination-processor']
  id: my-http-monitor-3
  ipv4: true
  ipv6: true
  mode: any
  name: partner-origination-status-app-2
  schedule: '@every 5s'
  ssl.verification_mode: none
  type: http
  tags:
    - Status App
    - Stage-server
```
</details>

1. Test the heartbeat configuration `heartbeat test config`

1. Setup heartbeat `sudo heartbeat setup`

1. Enable heartbeat-elastic.service `sudo systemctl enable heartbeat-elastic.service`

1. Start the heartbeat-elastic `sudo systemctl start heartbeat-elastic`

1. Restart heartbeat-elastic.service `sudo systemctl restart heartbeat-elastic.service`

1. Check heartbeat-elastic status `sudo systemctl status heartbeat-elastic`

## Python script
1. `vi /etc/heartbeat/monitors.d/port-fetching-python-script.py`
1. Copy and paste it by the following content.
    <details>
        <summary>Click to expand</summary>

    ```
    import subprocess
    import yaml

    # Function to get exposed ports from running Docker containers
    def get_exposed_ports():
        """
        Extract exposed ports mapped on the host system from the Docker containers.
        Returns:
            dict: A dictionary where keys are container names and values are lists of exposed port numbers.
        """
        try:
            command = "docker ps --format '{{.Names}}\t{{.Ports}}'"
            result = subprocess.check_output(command, shell=True).decode().strip()

            ports_map = {}

            for line in result.split("\n"):
                parts = line.split("\t", 1)  # Split each line into container name and port mappings
                if len(parts) == 2:
                    name, ports = parts
                    exposed_ports = []

                    # Extract only the exposed (host-mapped) ports
                    for port_mapping in ports.split(","):
                        if "->" in port_mapping:  # Look for mappings like "0.0.0.0:32777->2222/tcp"
                            exposed_port = port_mapping.split(":")[1].split("->")[0]
                            exposed_ports.append(exposed_port)

                    ports_map[name.strip()] = exposed_ports

            return ports_map
        except subprocess.CalledProcessError as e:
            print(f"Error running docker ps command: {e}")
            return {}
        except Exception as e:
            print(f"Unexpected error: {e}")
            return {}

    # Function to update YAML file with exposed ports
    def update_yaml_with_ports(yaml_file, ports_map):
        """
        Update the YAML file with the exposed ports from the Docker containers.

        Args:
            yaml_file (str): Path to the YAML file to update.
            ports_map (dict): A dictionary where keys are container names and values are lists of exposed ports.
        """
        try:
            # Load the YAML file
            with open(yaml_file, 'r') as file:
                yaml_data = yaml.safe_load(file)

            updated = False

            # Iterate through each monitor configuration in the YAML file
            for monitor in yaml_data:
                if 'name' in monitor and 'hosts' in monitor:
                    container_name = monitor['name'].lower()

                    # Match container name from ports_map and update port
                    for docker_name, exposed_ports in ports_map.items():
                        if container_name in docker_name.lower() and exposed_ports:
                            host_url = monitor['hosts'][0]  # Assume first URL in hosts
                            protocol, rest = host_url.split('://')
                            base_url, *context_path = rest.split('/', 1)

                            # Replace the port in the base URL while preserving the context path
                            updated_host = f"{protocol}://{base_url.split(':')[0]}:{exposed_ports[0]}"
                            if context_path:
                                updated_host += f"/{context_path[0]}"
                            monitor['hosts'][0] = updated_host
                            updated = True

            # Write the updated YAML data back to the file if changes were made
            if updated:
                with open(yaml_file, 'w') as file:
                    yaml.safe_dump(yaml_data, file)
                print(f"Updated YAML file: {yaml_file}")
            else:
                print("No matching containers found to update.")

        except FileNotFoundError:
            print(f"File not found: {yaml_file}")
        except yaml.YAMLError as e:
            print(f"Error parsing YAML file: {e}")
        except Exception as e:
            print(f"Unexpected error: {e}")

    # Example usage
    if __name__ == "__main__":
        yaml_file = "sample.http.yml"
        ports_map = get_exposed_ports()
        update_yaml_with_ports(yaml_file, ports_map)
    ```
    </details>

3. Go to `cd /etc/heartbeat/monitors.d/`
4. Run the python script `python3 port-fetching-python-script.py`
4. `sudo systemctl start heartbeat-elastic` (rerun the heartbeat)


## Filebeat

1. Install Filebeat
   1. `curl -L -O https://artifacts.elastic.co/downloads/beats/filebeat/filebeat-7.17.24-x86_64.rpm`
   1. `sudo rpm -ivh filebeat-7.17.24-x86_64.rpm`

1. Backup /etc/filebeat/filebeat.yml
   1. `mv /etc/filebeat/filebeat.yml  /etc/filebeat/filebeat.yml_bkp`

1. Edit the /etc/filebeat/filebeat.yml
   1. `sudo vi /etc/filebeat/filebeat.yml`
   1. Copy and paste it with the following content.
<details>
    <summary>Click to expand</summary>

```
###################### Filebeat Configuration Example #########################

# This file is an example configuration file highlighting only the most common
# options. The filebeat.reference.yml file from the same directory contains all the
# supported options with more comments. You can use it as a reference.
# You can find the full configuration reference here:
# https://www.elastic.co/guide/en/beats/filebeat/index.html

# For more available modules and options, please see the filebeat.reference.yml sample
# configuration file.

# ============================== Filebeat inputs ===============================

filebeat.inputs:

# Each - is an input. Most options can be set at the input level, so
# you can use different inputs for various configurations.
# Below are the input specific configurations.

# filestream is an input for collecting log messages from files.
- type: filestream

  # Unique ID among all inputs, an ID is required.
  id: usermanagement-server

  # Change to true to enable this input configuration.
  enabled: false

  # Paths that should be crawled and fetched. Glob based paths.
  paths:
    - /var/log/*.log
    - /nimbus/apps/logs/*/*/*.log
    - /nimbus/apps/logs/*/*/*.log.gz
    #- c:\programdata\elasticsearch\logs\*

- type: filestream
  id: "nginx-logs"  # Unique identifier for this input
  enabled: true
  paths:
    - /nimbus/apps/logs/nginx/*.log
  parsers :
    - ndjson:
        keys_under_root: true
        add_error_key: true

- type: filestream
  id: "npos-api-logs"
  enabled: true
  paths:
     - /var/log/*.*log
     - /nimbus/apps/logs/*/*/nimbus*.*
     - /nimbus/apps/logs/*/*/nimbus*.*
       #- /nimbus/apps/logs/*/nimbus-partner-origination-processor-milestone.*
       #- /nimbus/apps/logs/*/nimbus-partner-origination-processor-json.*
       #- /nimbus/apps/logs/*/nimbus-partner-origination-processor-monitor.*
       #- /nimbus/apps/logs/*/nimbus-partner-origination-processor.*
  parsers :
    - ndjson:
        keys_under_root: true
        add_error_key: true


  # Exclude lines. A list of regular expressions to match. It drops the lines that are
  # matching any regular expression from the list.
  #exclude_lines: ['^DBG']

  # Include lines. A list of regular expressions to match. It exports the lines that are
  # matching any regular expression from the list.
  #include_lines: ['^ERR', '^WARN']

  # Exclude files. A list of regular expressions to match. Filebeat drops the files that
  # are matching any regular expression from the list. By default, no files are dropped.
  #prospector.scanner.exclude_files: ['.gz$']

  # Optional additional fields. These fields can be freely picked
  # to add additional information to the crawled log files for filtering
  # fields:
  #   service: status-app
  # fields_under_root: true
  # close_inactive: 5m
  # clean_inactive: 1h
  # scan_frequency: 1s
  # ignore_older: 24h
  # harvester_limit: 0
  # close_removed: true
  # close_eof: true
  #  level: debug
  #  review: 1

# ============================== Filebeat modules ==============================

filebeat.config.modules:
  # Glob pattern for configuration loading
  path: ${path.config}/modules.d/*.yml

  # Set to true to enable config reloading
  reload.enabled: false

  # Period on which files under path should be checked for changes
  #reload.period: 10s

# ======================= Elasticsearch template setting =======================

setup.template.settings:
  index.number_of_shards: 1
  index.codec: best_compression
  #_source.enabled: false


# ================================== General ===================================

# The name of the shipper that publishes the network data. It can be used to group
# all the transactions sent by a single shipper in the web interface.
#name: "status-app-log"

# The tags of the shipper are included in their own field with each
# transaction published.
#tags: ["service-X", "web-tier"]

# Optional fields that you can specify to add additional information to the
# output.
fields:
  env: stage

# ================================= Dashboards =================================
# These settings control loading the sample dashboards to the Kibana index. Loading
# the dashboards is disabled by default and can be enabled either by setting the
# options here or by using the `setup` command.
#setup.dashboards.enabled: true

# The URL from where to download the dashboards archive. By default this URL
# has a value which is computed based on the Beat name and version. For released
# versions, this URL points to the dashboard archive on the artifacts.elastic.co
# website.
#setup.dashboards.url:

# =================================== Kibana ===================================

# Starting with Beats version 6.0.0, the dashboards are loaded via the Kibana API.
# This requires a Kibana endpoint configuration.
setup.kibana:

  host: "10.91.20.65:5601"
  username: "elastic"
  password: "Nimbus@2K24"
  # Kibana Host
  # Scheme and port can be left out and will be set to the default (http and 5601)
  # In case you specify and additional path, the scheme is required: http://localhost:5601/path
  # IPv6 addresses should always be defined as: https://[2001:db8::1]:5601
  # host: "10.91.16.44:5601"
  # username: "elastic"
  # password: "Nimbus@2K24"

  # Kibana Space ID
  # ID of the Kibana Space into which the dashboards should be loaded. By default,
  # the Default Space will be used.
  #space.id:

# =============================== Elastic Cloud ================================

# These settings simplify using Filebeat with the Elastic Cloud (https://cloud.elastic.co/).

# The cloud.id setting overwrites the `output.elasticsearch.hosts` and
# `setup.kibana.host` options.
# You can find the `cloud.id` in the Elastic Cloud web UI.
#cloud.id:

# The cloud.auth setting overwrites the `output.elasticsearch.username` and
# `output.elasticsearch.password` settings. The format is `<user>:<pass>`.
#cloud.auth:

# ================================== Outputs ===================================

# Configure what output to use when sending the data collected by the beat.

# ---------------------------- Elasticsearch Output ----------------------------
output.elasticsearch:
  # Array of hosts to connect to.
  hosts: ["10.91.20.65:9200"]

  # Protocol - either `http` (default) or `https`.
  protocol: "https"

  # Authentication credentials - either API key or username/password.
  #api_key: "id:api_key"
  username: "elastic"
  password: "Nimbus@2K24"
  # index: "application-logs-%{[fields.env]}-%{+yyyy.MM.dd}"
  ssl:
    verification_mode: "none"

# ------------------------------ Logstash Output -------------------------------
#output.logstash:
  # The Logstash hosts
  #hosts: ["localhost:5044"]

  # Optional SSL. By default is off.
  # List of root certificates for HTTPS server verifications
  #ssl.certificate_authorities: ["/etc/pki/root/ca.pem"]

  # Certificate for SSL client authentication
  #ssl.certificate: "/etc/pki/client/cert.pem"

  # Client Certificate Key
  #ssl.key: "/etc/pki/client/cert.key"

# ================================= Processors =================================
processors:
  - add_host_metadata:
      when.not.contains.tags: forwarded
        #  - add_cloud_metadata: ~
  - add_docker_metadata: ~
    # - add_kubernetes_metadata: ~
  # - add_fields:
  #     target: ''
  #     fields:
  #       server_id: "status-app-logs"

# ================================== Logging ===================================

# Sets log level. The default log level is info.
# Available log levels are: error, warning, info, debug
# logging.level: debug

# At debug level, you can selectively enable logging only for some components.
# To enable all selectors use ["*"]. Examples of other selectors are "beat",
# "publisher", "service".
# logging.selectors: ["*"]

# ============================= X-Pack Monitoring ==============================
# Filebeat can export internal metrics to a central Elasticsearch monitoring
# cluster.  This requires xpack monitoring to be enabled in Elasticsearch.  The
# reporting is disabled by default.

# Set to true to enable the monitoring reporter.
#monitoring.enabled: false

# Sets the UUID of the Elasticsearch cluster under which monitoring data for this
# Filebeat instance will appear in the Stack Monitoring UI. If output.elasticsearch
# is enabled, the UUID is derived from the Elasticsearch cluster referenced by output.elasticsearch.
#monitoring.cluster_uuid:

# Uncomment to send the metrics to Elasticsearch. Most settings from the
# Elasticsearch output are accepted here as well.
# Note that the settings should point to your Elasticsearch *monitoring* cluster.
# Any setting that is not set is automatically inherited from the Elasticsearch
# output configuration, so if you have the Elasticsearch output configured such
# that it is pointing to your Elasticsearch monitoring cluster, you can simply
# uncomment the following line.
#monitoring.elasticsearch:

# ============================== Instrumentation ===============================

# Instrumentation support for the filebeat.
instrumentation:
    # Set to true to enable instrumentation of filebeat.
    enabled: true

    # Environment in which filebeat is running on (eg: staging, production, etc.)
    environment: "stage"

    # APM Server hosts to report instrumentation results to.
    hosts:
      - http://10.91.20.65:8200

    # API Key for the APM Server(s).
    # If api_key is set then secret_token will be ignored.
    #api_key:

    # Secret token for the APM Server(s).
    secret_token: Nimbus@2K24


# ================================= Migration ==================================

# This allows to enable 6.7 migration aliases
#migration.6_to_7.enabled: true
# setup.template.name: "application-logs"
# setup.template.pattern: "application-logs-*"
# setup.template.enabled: true

# # Optional: Index-specific settings
# setup.template.settings:
#   index.number_of_shards: 1
#   index.number_of_replicas: 1
```
</details>


4. Enable filebeat modules `sudo filebeat modules enable system`

5. Verify enable modules `filebeat modules list`

6. Setup filebeat `sudo filebeat setup --dashboards`

7. Start filebeat `sudo systemctl start filebeat`

8. Enable filebeat `sudo systemctl enable filebeat`

9. Check the filebeat `sudo systemctl status filebeat`
